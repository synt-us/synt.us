/* The configuration header file */
/* $Id$ */

#ifndef HED__CONFIG_H
#define HED__CONFIG_H

/*
 * 'Mercy!' cried Gandalf. 'If the giving of information is to be the cure of
 * your inquisitiveness, I shall spend all the rest of my days in answering
 * you. What more do you want to know?'
 *
 * 'The names of all the stars, and of all living things, and the whole history
 * of Middle-earth and Over-heaven and of the Sundering Seas,' laughed Pippin.
 */


/* Uncomment this if you want the EXPERIMENTAL mmap file backend */
/* #define CONFIG_MMAP 1 */

/* Comment this out if you don't want to compile readahead in */
#define CONFIG_READAHEAD 1

/* Below, several macros are defined. Modify them according to your system. */

/* Enable useful extensions. */
#define _XOPEN_SOURCE 500
#define _GNU_SOURCE

/* Comment out or change to 32 if your system does not support 64-bit file
 * sizes. */
#define _FILE_OFFSET_BITS 64

/* Comment out if your system does not have getopt_long(). */
#define HAVE_GETOPT_LONG

/* The biggest integer type available on the system. */
#define BINT_TYPE long long

#endif
