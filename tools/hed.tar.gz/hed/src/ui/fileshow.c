/* $Id$ */

/*
 * hed - Hexadecimal editor
 * Copyright (C) 2004  Petr Baudis <pasky@ucw.cz>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/*
 * As Beren looked into her eyes
 * Within the shadows of her hair,
 * The trembling starlight of the skies
 * He saw there mirrored shimmering.
 * Tinuviel the elven-fair,
 * Immortal maiden elven-wise,
 * About him cast her shadowy hair
 * And arms like silver glimmering.
 */

#include "config.h"

#include <ctype.h>
#include <curses.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#include "hed.h"

#include "config/config.h"
#include "eval/eval.h"
#include "file/file.h"
#include "term/term.h"
#include "ui/core.h"
#include "ui/error.h"
#include "ui/fileshow.h"
#include "ui/inputline.h"
#include "util/lists.h"
#include "main.h"

/* For now, we re-request the file fragment each time we redraw the thing.
 * This might not be feasible in the future. */

/* Number of bytes to fetch at cursor position.
 * Currently, at maximum 4 bytes are needed (for the s32/u32 display).
 * If you need more in print_fileview_status, feel free to increase
 * this constant and use the extra bytes.
 */
#define CURSOR_LENGTH	4

/* TODO: Make the multiclipboard smarter - copy-on-write. */
/* TODO: Registers should work as in vim, esp. the unnamed (") register */
struct clipboard_register {
	unsigned char *data;
	off_t len;
};
static struct clipboard_register clipboard[1 + 'z' - 'a' + 1 + 'Z' - 'A' + 1 + '9' - '0' + 1];
static inline char
ch2reg(char ch)
{
	return ('A' <= ch && ch <= 'Z') ? ch - 'A' :
		('a' <= ch && ch <= 'z') ? 26 + ch - 'a' :
		('0' <= ch && ch <= '9') ? 52 + ch - '0' :
		(ch == '"') ? 62 :
		-1;
}


static bool subst_all;


struct fileshow_priv {
	struct file *file;
	blockoff_t offset;	/* Beginning of screen (file offset) */

	blockoff_t cursor;	/* Cursor position (file offset) */
	int digitpos; /* Selected digit in the hexadecimal column. */
	unsigned char curbyte; /* The value of the current byte under the cursor. */

	blockoff_t insert;

	char idmark;		/* insertion/deletion mark at screen start */

	struct expression *last_search;
	enum { SDIR_FORWARD = 1, SDIR_BACK = -1 } last_search_dir;

	enum { FSC_HEX, FSC_ASC } column;
	enum ui_mode mode;

	off_t visual_start;

	int reg;
};

static enum handler_result fileshow_handler(struct ui_component *, const struct ui_event *);
static void eval_reg_cb(void *hookdata, char reg, bint ofs, int bpos, unsigned char *scramble, int len);
static void eval_mark_cb(void *hookdata, char mark, int bpos, unsigned char *scramble, int len);

enum ui_mode opt_defmode = -1;

static int width;
static int height = 0;
/* Size of the file portion shown on the screen at one time. */
static ssize_t ssize = 0;

static void
update_idmark(struct fileshow_priv *data)
{
	char idmark = ' ';

	if (file_pos_after_erase(data->file, &data->offset))
		idmark = '|';
	if (block_is_inserted(data->offset.block) &&
	    !data->offset.off)
		idmark = (idmark == '|') ? ')' : '>';
	data->idmark = idmark;
}

static void
set_viewport(struct fileshow_priv *data, off_t pos)
{
	file_get_blockoff(data->file, pos, &data->offset);
	update_idmark(data);
}

/* Update screen offset to make cursor fit into the current viewport */
static void
fixup_viewport(struct fileshow_priv *data)
{
	off_t curline = data->cursor.pos - data->cursor.pos % width;

	if (curline < data->offset.pos)
		set_viewport(data, curline);
	else if (curline - ssize >= data->offset.pos)
		set_viewport(data, curline - ssize + width);
}

static void
set_cursor(struct fileshow_priv *data, off_t pos)
{
	file_get_blockoff(data->file, pos, &data->cursor);
	fixup_viewport(data);
}

/* Update cursor position to fit into the current viewport */
static void
fixup_cursor(struct fileshow_priv *data)
{
	off_t curline = data->cursor.pos - data->cursor.pos % width;

	if (curline < data->offset.pos)
		file_move_relative(&data->cursor,
				   data->offset.pos - curline);
	else if (curline >= data->offset.pos + ssize)
		file_move_relative(&data->cursor,
				   data->offset.pos + ssize - width - curline);
}

static void
slide_viewport(struct fileshow_priv *data, off_t num)
{
	file_move_relative(&data->offset, num);
	update_idmark(data);
	fixup_cursor(data);
}

/* Initialize the component. */
void
fileshow_init(struct file *file)
{
	struct fileshow_priv *data;
	struct ui_component *fileshow;

	data = calloc(1, sizeof(struct fileshow_priv));
	if (!data) goto nomem;
	data->file = file;
	data->reg = ch2reg('"');

	if ((int) opt_defmode >= 0) {
		data->mode = opt_defmode;
	} else {
		char *defmode = get_opt_str("default_mode", "normal");
		if (!strcmp(defmode, "normal")) {
			data->mode = MODE_NORMAL;
		} else if (!strcmp(defmode, "insert")) {
			data->mode = MODE_INSERT;
		} else if (!strcmp(defmode, "replace")) {
			data->mode = MODE_REPLACE;
		} else {
			data->mode = MODE_NORMAL;
		}
	}

	fileshow = ui_register(fileshow_handler, data);
	if (!fileshow) {
		free(data);
nomem:
		sched_exit(EX_OSERR);
		return;
	}

	/* TODO: Better height calculation. */
	height = term_get_max_y() - 2;
	width = (term_get_max_x() - /* ofs */ 8 - /* spaces */ 4);
	width /= 4;
	if (!opt_spreadview) {
		width = 1 << bitsize(width);
		width = get_opt_int("bytes_per_line", width);
	}
	ssize = height * width;

	file_get_blockoff(data->file, 0, &data->cursor);
	file_dup_blockoff(&data->cursor, &data->offset);
	data->idmark = ' ';
}

static void
fileshow_done(struct ui_component *comp)
{
	free(comp->data);
	ui_unregister(comp);
}


#define FMTLEN 32

/* Warning! print_status_num() peeks at the second-to-last character
 * of the @fmt string and decides on the signedness based on it! */
static void
print_status_num(int bwidth, char *fmt, int *x, int y,
                 unsigned char *cursdata)
{
	char *str = NULL;
	int len;
	unsigned long num = 0;
	unsigned long negpad = bwidth >= sizeof(negpad) ? ~0 : (1 << bwidth * 8) - 1;
	int i;

	assert(fmt && x && cursdata);

	for (i = 0; i < bwidth; i++)
		num |= *cursdata++ << (8 * i);
	/* Pad the rest of unsigned long according to the sign. */
	if (fmt[strlen(fmt) - 2] != 'u' && num >> (8 * bwidth - 1) == 1)
		num |= ~0 ^ negpad;

	len = asprintf((char **) &str, fmt, num);
	term_print_string(*x, y, COLOR_STATUS, str);
	free(str);
	*x += len;
}

static void
print_fileview_status(struct fileshow_priv *data,
		      unsigned char *cursdata, int ofslen)
{
	static char modechar[] = { 'N', 'R', 'I', 'V' };
	char fmt[FMTLEN];
	char *str = NULL;
	int pos = 0, len;

	/* We print the filename first so that it gets overwritten by
	 * the "more important" stuff. The most important part of the
	 * filename tends to be at the end anyway. */
	term_print_string(term_get_max_x() - 1 - strlen(data->file->name),
	                  height, COLOR_STATUS, data->file->name);

	snprintf(fmt, FMTLEN, "%%0%dllx: %%03d  ", ofslen);
	len = asprintf((char **) &str, fmt,
		       (unsigned long long) data->cursor.pos, *cursdata);
	term_print_string(0, height, COLOR_STATUS, str);
	free(str);
	pos += len;

	/* TODO: Big endian. */
	term_print_string(pos, height, COLOR_STATUS, "LE: ");
	pos += 4;

	/* See the print_status_num() warning above. */
	print_status_num(2, "u16:%6lu ", &pos, height, cursdata);
	print_status_num(2, "s16:%6ld ", &pos, height, cursdata);
	print_status_num(4, "u32:%11lu ", &pos, height, cursdata);
	print_status_num(4, "s32:%11ld ", &pos, height, cursdata);

	term_print_char(pos, height, COLOR_MODE, data->file->modified ? '*' : ' ');
	term_print_char(pos + 1, height, COLOR_MODE, modechar[data->mode]);
}


static int
num_hex_width(off_t num)
{
	/* Offset of the leftmost non-zero bit. */
	int width = 0;
	int i;

	for (i = sizeof(off_t) * 8 / 2; i > 0; i /= 2) {
		/* C (gcc, subsequently) made every possible effort to make the following
		 * originally crystal-clear expression as convoluted and unreadable as
		 * possible. :-( */
		if (num & ((i * 2 >= sizeof(off_t) * 8 ? ~0 : ((off_t) 1 << (i * 2)) - 1)
			   ^ (((off_t) 1 << i) - 1))) {
			num >>= i; width += i;
		}
	}
	/* Round the width up to the hexadecimal places. */
	return width / 4 + 1;
}

static void
fileshow_redraw(struct ui_component *comp)
{
	struct fileshow_priv *data = comp->data;
	int row;
	ssize_t size = ssize + CURSOR_LENGTH;
	uoff_t totsize = file_size(data->file);
	uoff_t endpos;
	blockoff_t pos;
	char idmark;		/* insertion/deletion marks */

	int ofslen;
	char fmt[FMTLEN];

	const int xascshift = width * 3 + 1;
	int xindent;

	unsigned char *p;
	unsigned char cursdata[CURSOR_LENGTH];

	if (file_read_begin(data->file, &data->offset, size)) {
		/* TODO: Better error reporting. */
		perror("file_read_begin");
		return;
	}

	/* Offset width is chosen to accomodate the whole file in its current
	 * size as well as the current screen. It is also always at least 4. */
	/* FIXME: Portability to systems with 32bit offset. */
	ofslen = max(4, num_hex_width(max(file_size(data->file),
	                                  data->offset.pos + ssize)));
	snprintf(fmt, FMTLEN, "%%0%dllx  ", ofslen);

	file_dup_blockoff(&data->offset, &pos);
	endpos = file_block_size(pos.block);
	p = block_data(pos.block) + pos.off;
	idmark = data->idmark;

	for (row = 0; row < height; row++) {
		char *str;
		int len;
		int col;

		xindent = 0;

		len = asprintf((char **) &str, fmt, pos.pos);
		term_print_string(0, row, COLOR_OFS, str);
		free(str);
		xindent += len;
		term_print_char(xindent + xascshift - 1, row, COLOR_OFS, ' ');

		for (col = 0; col < width; col++, pos.pos++, pos.off++) {
			char hex[5];
			unsigned char asc;
			char v = 0;
			term_color color;

			if (pos.off >= endpos) {
				if (block_is_inserted(pos.block))
					idmark = '<';
				file_next_block(data->file, &pos);
				if (block_is_inserted(pos.block))
					idmark = idmark == '<' ? ' ' : '>';
				if (file_pos_after_erase(data->file, &pos))
					switch(idmark) {
					case '<': idmark = '('; break;
					case '>': idmark = ')'; break;
					default:  idmark = '|';
					}

				p = block_data(pos.block) + pos.off;
				endpos = file_block_size(pos.block);
			}

			if (data->mode == MODE_VISUAL) {
				v = (data->cursor.pos <= data->visual_start
						? data->cursor.pos <= pos.pos && pos.pos <= data->visual_start
						: data->visual_start <= pos.pos && pos.pos <= data->cursor.pos);
			}

			asc = file_pos_valid(data->file, &pos)
				? file_read_deref(p++) : 0x00;
			snprintf(hex, 4, "%02x ", asc);
			asc = isprint(asc) ? asc : asc == '\0' ? '.' : ':';

			if (!v) {
				color = COLOR_DATA_BASE;
				if (pos.pos == data->cursor.pos)
					color |= COLOR_DATA_CURSOR;
				else if (block_bytedirty(&pos))
					color = COLOR_DIRTY;
				if (pos.pos >= totsize)
					color |= COLOR_DATA_OUTSIDE;
			} else
				color = COLOR_VISUAL;

			if (col || idmark != '<')
				term_print_char(xindent + col * 3 - 1, row,
						idmark==' ' ? color : COLOR_OFS,
						idmark);
			else
				term_print_char(xindent + width*3 - 1, row - 1,
						COLOR_OFS, idmark);
			term_print_string(xindent + col * 3, row,
					  color, hex);
			if (!v)
				color |= COLOR_DATA_ASCII;
			term_print_char(xindent + xascshift + col, row,
					color, asc);
			idmark = ' ';
		}
		// Clear the rest of line after the ASCII listing.
		clrtoeol();
	}
	file_put_blockoff(&pos);

	if (data->column == FSC_HEX) {
		cursor_x = (data->cursor.pos - data->offset.pos) % width * 3 + xindent + data->digitpos;
	} else {
		cursor_x = (data->cursor.pos - data->offset.pos) % width + xindent + xascshift;
	}
	cursor_y = (data->cursor.pos - data->offset.pos) / width;

	assert(data->cursor.pos >= 0);

	memset(cursdata, 0, sizeof(cursdata));
	file_cpin(data->file, cursdata, sizeof(cursdata), &data->cursor);
	data->curbyte = cursdata[0];

	file_read_end(data->file);

	print_fileview_status(data, cursdata, ofslen);
}

#undef FMTLEN

/* Jump to a position given by offset expression. */
static void
jump_offset(struct inputline_data *inpline, void *hookdata)
{
	struct fileshow_priv *data = hookdata;
	struct expression *expr = expr_compile(inpline->buf);
	int len; unsigned char *buf;
	off_t pos;

	if (!expr) {
		errmsg("Invalid expression");
		return;
	}
	len = expr_len(expr);
	buf = expr_eval(expr, eval_reg_cb, eval_mark_cb, data);
	expr_free(expr);
	pos = (off_t) bytestr2num(buf, len);
	free(buf);

	/* off_t is signed, but we couldn't have got a signed value
	 * in, so it's an overflow if it is negative now. */
	if (pos < 0)
		pos = OFF_MAX;
	set_cursor(data, pos);
}

static int
jump_relative(struct fileshow_priv *data, int num)
{
	/* Zero-length jump usually means an invalid jump out of bounds */
	if (file_move_relative(&data->cursor, num) == 0)
		return -1;

	data->digitpos = 0;
	fixup_viewport(data);
	return 0;
}

static void
finish_insert(struct fileshow_priv *data)
{
	if (is_a_blockoff(&data->insert)) {
		file_insert_end(data->file, &data->insert);
		if (data->column == FSC_HEX && data->digitpos)
			jump_relative(data, 1);
	}
}

static void
erase_at_cursor(struct fileshow_priv *data, uoff_t len)
{
	file_erase_block(data->file, &data->cursor, len);
	if (!is_a_blockoff(&data->offset)) {
		file_dup2_blockoff(&data->cursor, &data->offset);
		file_move_relative(&data->offset, -data->offset.pos % width);
		update_idmark(data);
	}
}

static off_t
do_search(struct fileshow_priv *data)
{
	blockoff_t off;
	int res;

	file_dup_blockoff(&data->cursor, &off);
	file_move_relative(&off, data->last_search_dir);
	res = file_find_expr(data->file, &off, data->last_search_dir,
	                     data->last_search, eval_reg_cb, data);
	if (!res)
		set_cursor(data, off.pos);
	else if (!subst_all)
		errmsg("No match found");

	file_put_blockoff(&off);
	return off.pos;
}

/* Search for the given string. */
static void
expr_search(struct inputline_data *inpline, void *hookdata)
{
	struct fileshow_priv *data = hookdata;

	if (data->last_search)
		expr_free(data->last_search);
	data->last_search = expr_compile(inpline->buf);
	if (!data->last_search) {
		errmsg("Invalid expression");
		return;
	}

	do_search(data);
}

/* Search and substitute the given string. */
static void
expr_subst(struct inputline_data *inpline, void *hookdata)
{
	struct fileshow_priv *data = hookdata;
	struct expression *subst;
	unsigned char *buf;
	int mlen, len;

	subst = expr_compile(inpline->buf);
	if (!subst) {
		errmsg("Invalid expression");
		return;
	}

	data->last_search_dir = SDIR_FORWARD;
	while (do_search(data) != FINDOFF_NO_MATCH) {
		blockoff_t blockoff;
		/* Cursor at the match */
		mlen = expr_len(data->last_search);
		erase_at_cursor(data, mlen);
		len = expr_len(subst);
		buf = expr_eval(subst, eval_reg_cb, eval_mark_cb, data);
		file_insert_begin(data->file, &data->cursor, &blockoff);
		file_insert_block(data->file, &blockoff, buf, len);
		file_insert_end(data->file, &blockoff);
		if (!subst_all)
			break;
	}
	expr_free(subst);
}

static void
expr_subst1(struct inputline_data *inpline, void *hookdata)
{
	struct fileshow_priv *data = hookdata;

	if (data->last_search)
		expr_free(data->last_search);
	data->last_search = expr_compile(inpline->buf);
	if (!data->last_search) {
		errmsg("Invalid expression");
		return;
	}
	inputline_init("s/.../", expr_subst, data);
}

/* Returns ZERO ON ERROR. */
static size_t
visual_extents(struct fileshow_priv *data, blockoff_t *base)
{
	size_t ret;
	if (data->visual_start < data->cursor.pos) {
		ret = data->cursor.pos - data->visual_start + 1;
		file_get_blockoff(data->file, data->visual_start, base);
	} else {
		ret = data->visual_start - data->cursor.pos + 1;
		*base = data->cursor;
	}
	return ret;
}

static void
clip_yank(struct fileshow_priv *data)
{
	blockoff_t base = NULL_BLOCKOFF;
	size_t len = visual_extents(data, &base);

	file_put_blockoff(&base);
	if (clipboard[data->reg].data)
		free(clipboard[data->reg].data);
	clipboard[data->reg].data =
		file_fetch_block(data->file, base.pos, &len);
	clipboard[data->reg].len = len;
}

/* Those functions are totally horrible kludges. There should be specialized
 * file methods for those operations. */

static void
clip_delete(struct fileshow_priv *data)
{
	size_t len;

	clip_yank(data);
	len = visual_extents(data, &data->cursor);
	erase_at_cursor(data, len);
}

static void
clip_put(struct fileshow_priv *data)
{
	blockoff_t blkoff;
	if (!clipboard[data->reg].data) {
		errmsg("Register empty");
		return;
	}
	file_insert_begin(data->file, &data->cursor, &blkoff);
	file_insert_block(data->file, &blkoff, clipboard[data->reg].data, clipboard[data->reg].len);
	file_insert_end(data->file, &blkoff);
	if (data->offset.pos == data->cursor.pos)
		file_move_relative(&data->offset, -clipboard[data->reg].len);
}

static void
clip_overwrite(struct fileshow_priv *data)
{
	blockoff_t start = NULL_BLOCKOFF;
	off_t i;
	ssize_t len;

	if (!clipboard[data->reg].data) {
		errmsg("Register empty");
		return;
	}

	if (data->mode == MODE_VISUAL) {
		/* spill */
		len = visual_extents(data, &start);
	} else {
		/* splat */
		file_dup_blockoff(&data->cursor, &start);
		len = clipboard[data->reg].len;
	}

	i = min(len, clipboard[data->reg].len);
	file_set_block(data->file, &start, clipboard[data->reg].data, i);
	file_move_relative(&start, i);
	file_set_bytes(data->file, &start, 0, len - i);
	file_put_blockoff(&start);
}

static void
clip_swap(struct fileshow_priv *data)
{
	struct clipboard_register orig, new;

	new = clipboard[data->reg];
	clipboard[data->reg].data = NULL;
	clip_delete(data);
	orig = clipboard[data->reg];
	clipboard[data->reg] = new;
	clip_put(data);
	clipboard[data->reg] = orig;
}


static void
set_width(struct inputline_data *inpline, void *hookdata)
{
	char *l;
	int w;
	w = strtol(inpline->buf, &l, 0);
	if (*l) {
		errmsg("Invalid width");
		return;
	}
	width = w;
	ssize = height * width;
}


static void
read_region(struct inputline_data *inpline, void *hookdata)
{
	struct fileshow_priv *data = hookdata;
	char *fname = inpline->buf;
	int flen = inpline->buf_len;
	FILE *f;
	int ch;

	/* Trim leading/trailing whitespaces */
	while (isspace(*fname))
		fname++, flen--;
	while (isspace(fname[flen - 1]) && flen > 0)
		flen--;
	if (!*fname)
		return;
	f = fopen(fname, "r");
	if (!f) {
		errmsg(strerror(errno));
		return;
	}

	if (data->mode == MODE_VISUAL) {
		size_t len = visual_extents(data, &data->cursor);
		erase_at_cursor(data, len);
	}

	/* Ugh. :-) */
	file_insert_begin(data->file, &data->cursor, &data->insert);
	while ((ch = fgetc(f)) != EOF)
		file_insert_byte(data->file, &data->insert, ch);
	finish_insert(data);
	fclose(f);
}

static void
write_region(struct inputline_data *inpline, void *hookdata)
{
	struct fileshow_priv *data = hookdata;
	blockoff_t base = NULL_BLOCKOFF;
	size_t len = visual_extents(data, &base);
	unsigned char *buf;
	char *fname = inpline->buf;
	int flen = inpline->buf_len;
	FILE *f;

	file_put_blockoff(&base);

	/* Trim leading/trailing whitespaces */
	while (isspace(*fname))
		fname++, flen--;
	while (isspace(fname[flen - 1]) && flen > 0)
		flen--;
	if (!*fname)
		return;

	/* FIXME: Don't do it at once */
	buf = file_fetch_block(data->file, base.pos, &len);
	f = fopen(fname, "w");
	if (!f) {
		errmsg(strerror(errno));
		free(buf);
		return;
	}
	fwrite(buf, len, 1, f);
	fclose(f);
	free(buf);
}


static int
filter_select(struct fileshow_priv *data, off_t base, ssize_t len, int fd_in, int fd_out)
{
	fd_set fdr, fdw;
	int ret;

	file_insert_begin(data->file, &data->cursor, &data->insert);
	while (fd_out || fd_in) {
		FD_ZERO(&fdr);
		FD_ZERO(&fdw);
		if (fd_in) FD_SET(fd_in, &fdr);
		if (fd_out) FD_SET(fd_out, &fdw);

		ret = select(fd_in+fd_out+1, &fdr, &fdw, NULL, NULL);

		if (ret <= 0)
			continue;

		if (FD_ISSET(fd_in, &fdr)) {
			unsigned char buf[FILE_BLOCK_SIZE];
			ret = read(fd_in, buf, FILE_BLOCK_SIZE);
			if (ret < 0)
				goto err;
			if (ret == 0) {
				close(fd_in);
				fd_in = 0;
			}
			file_insert_block(data->file, &data->insert, buf, ret);
			data->cursor.pos += ret;
		}

		if (FD_ISSET(fd_out, &fdw)) {
			size_t blen = min(len, FILE_BLOCK_SIZE);
			unsigned char *buf = file_fetch_block(data->file, base, &blen);
			if (blen < FILE_BLOCK_SIZE) {
				len = 0;
			} else {
				len -= blen;
			}
			ret = write(fd_out, buf, blen);
			free(buf);
			if (ret <= 0)
				goto err;
			if (ret < blen)
				len += blen - ret;
			base += ret;

			if (!len) {
				close(fd_out);
				fd_out = 0;
			}
		}
	}
	finish_insert(data);
	return 0;
err:
	finish_insert(data);
	if (fd_out)
		close(fd_out);
	if (fd_in)
		close(fd_in);
	return -1;
}

static void
pipe_region(struct inputline_data *inpline, void *hookdata)
{
	struct fileshow_priv *data = hookdata;
	blockoff_t base = NULL_BLOCKOFF;
	size_t len = visual_extents(data, &base);
	char *argv[4] = { "/bin/sh", "-c", inpline->buf, NULL };
	int p_rd[2], p_wr[2];
	pid_t pid;

	file_put_blockoff(&base);

	data->mode = MODE_NORMAL;

	pipe(p_rd);
	pipe(p_wr);

	pid = fork();
	if (pid == 0) {
		close(p_rd[1]);
		close(p_wr[0]);

		dup2(p_rd[0], 0);
		dup2(p_wr[1], 1);

		exit(execvp(argv[0], argv));

	} else if (pid > 0) {
		int status, ret;

		close(p_rd[0]);
		close(p_wr[1]);

		set_cursor(data, base.pos + len);
		if (filter_select(data, base.pos, len, p_wr[0], p_rd[1]) < 0) {
			errmsg("Filter failed");
			return;
		}
		ret = waitpid(pid, &status, 0);
		if (ret != pid) {
			errmsg("Funny zombie");
			return;
		}
		if (WIFEXITED(status)) {
			if (WEXITSTATUS(status))
				errmsg("Filter returned error");
			set_cursor(data, base.pos);
			erase_at_cursor(data, len);
			return;
		}
		errmsg("Curious error");
		return;

	} else {
		errmsg("Fork failed");
		return;
	}
}

static blockoff_t xre;

static void
eval_mark_cb(void *hookdata, char mark, int bpos, unsigned char *scramble, int len)
{
	struct fileshow_priv *data = hookdata;
	int m = ch2mark(mark);
	if (m >= 0) {
		if (is_a_blockoff(&data->file->marks[m])) {
			num2bytestr(scramble, len, data->file->marks[m].pos);
			return;
		}
	} else {
		if (mark == '$') {
			num2bytestr(scramble, len, data->cursor.pos);
			return;
		}
	}
	memset(scramble, 0, len);
}


static void
eval_reg_cb(void *hookdata, char reg, bint ofs, int bpos, unsigned char *scramble, int len)
{
	struct fileshow_priv *data = hookdata;
	unsigned char *buf, *free_buf = NULL;
	size_t blen, sofs = 0;
	int r = ch2reg(reg);
	if (r >= 0) {
		buf = free_buf = clipboard[r].data; blen = clipboard[r].len;
		if (ofs < 0) {
			memset(scramble, 0, min(len, -ofs));
			sofs = -ofs, ofs = 0;
		}
		if (sofs >= len)
			goto free_buf;
		len -= sofs;
scramble_buf:
		if (blen < 0)
			blen = 0;
		if (buf)
			memcpy(scramble + sofs, buf, min(len, blen));
		if (blen < len)
			memset(scramble + sofs + blen, 0, len - blen);
free_buf:
		if (free_buf)
			free(free_buf);
		return;
	}

	blen = len;
	switch (reg) {
		case ',':
			buf = file_fetch_block(data->file, max(0, data->cursor.pos + ofs), &blen);
			goto scramble_buf;
		case '_':
			buf = file_fetch_block(data->file, max(0, ofs), &blen);
			goto scramble_buf;
		case ':':
			num2bytestr(scramble, len, data->cursor.pos);
			if (-len < ofs && ofs < len) {
				if (ofs < 0) {
					memset(scramble, 0, -ofs);
					sofs = -ofs, ofs = 0;
					len -= sofs;
				}
				memmove(scramble + sofs, scramble + ofs, len - ofs);
				memset(scramble + sofs + ofs, 0, len - ofs);
			} else {
				memset(scramble, 0, len);
			}
			break;
		case '.':
			if (is_a_blockoff(&xre)) {
				buf = file_fetch_block(data->file,
				                       max(0, xre.pos + bpos + ofs),
				                       &blen);
				goto scramble_buf;
			}
		default:
			memset(scramble, 0, len);
			break;
	}
}


static void
ieval_expr(struct inputline_data *inpline, void *hookdata)
{
	struct fileshow_priv *data = hookdata;
	struct expression *expr = expr_compile(inpline->buf);
	int len;
	unsigned char *buf;
	blockoff_t blkoff;

	if (!expr) {
		errmsg("Invalid expression");
		return;
	}
	len = expr_len(expr);
	buf = expr_eval(expr, eval_reg_cb, eval_mark_cb, data);
	expr_free(expr);
	file_insert_begin(data->file, &data->cursor, &blkoff);
	file_insert_block(data->file, &blkoff, buf, len);
	file_insert_end(data->file, &blkoff);
	free(buf);
}

static void
peval_expr(struct inputline_data *inpline, void *hookdata)
{
	struct fileshow_priv *data = hookdata;
	struct expression *expr = expr_compile(inpline->buf);
	static char resbuf[128];
	int len;
	unsigned char *buf;

	if (!expr) {
		errmsg("Invalid expression");
		return;
	}
	len = expr_len(expr);
	buf = expr_eval(expr, eval_reg_cb, eval_mark_cb, data);
	expr_free(expr);
	snprintf(resbuf, 128, "Result: %llu (%d bytes)", bytestr2num(buf,len), len);
	errmsg(resbuf);
	free(buf);
}


static void
reval_expr(struct inputline_data *inpline, void *hookdata)
{
	struct fileshow_priv *data = hookdata;
	struct expression *expr = expr_compile(inpline->buf);
	int i, elen;
	unsigned char *ebuf;
	size_t len;

	if (!expr) {
		errmsg("Invalid expression");
		return;
	}
	elen = expr_len(expr);
	len = visual_extents(data, &xre);
	for (i = 0; i < len / elen; i++) {
		ebuf = expr_eval(expr, eval_reg_cb, eval_mark_cb, data);
		file_set_block(data->file, &xre, ebuf, elen);
		free(ebuf);
		file_move_relative(&xre, elen);
	}
	ebuf = expr_eval(expr, eval_reg_cb, eval_mark_cb, data);
	expr_free(expr);
	file_set_block(data->file, &xre, ebuf, len % elen);
	free(ebuf);
	file_put_blockoff(&xre);
	xre.block = NULL;
}


static enum handler_result fileshow_normal_in(struct fileshow_priv *data, int ch);

/* Evaluate an exmode command. */
static void
exmode_cmd_write(struct fileshow_priv *data)
{
	if (data->mode == MODE_VISUAL) {
		/* Write just the visual */
		inputline_init("File: ", write_region, data);
	} else
		file_commit(data->file);
}
static void
exmode_cmd_read(struct fileshow_priv *data)
{
	inputline_init("File: ", read_region, data);
}
static void
exmode_cmd_pipe(struct fileshow_priv *data)
{
	inputline_init("Command: ", pipe_region, data);
}
static void
exmode_cmd_subst(struct fileshow_priv *data)
{
	subst_all = false;
	inputline_init("s/", expr_subst1, data);
}
static void
exmode_cmd_Subst(struct fileshow_priv *data)
{
	subst_all = true;
	inputline_init("S/", expr_subst1, data);
}
static void
exmode_cmd_swp(struct fileshow_priv *data)
{
	file_swp(data->file);
}
static void
exmode_cmd_ieval(struct fileshow_priv *data)
{
	inputline_init("Expression: ", ieval_expr, data);
}
static void
exmode_cmd_reval(struct fileshow_priv *data)
{
	if (data->mode != MODE_VISUAL)
		data->visual_start = data->cursor.pos;
	inputline_init("Expression: ", reval_expr, data);
}
static void
exmode_cmd_peval(struct fileshow_priv *data)
{
	inputline_init("Expression: ", peval_expr, data);
}
static void
exmode_cmd_width(struct fileshow_priv *data)
{
	inputline_init("Bytes per line: ", set_width, data);
}
static void
exmode_cmd_quit(struct fileshow_priv *data)
{
	terminus = true;
}
static void
exmode_cmd_exit(struct fileshow_priv *data)
{
	if (data->file->modified)
		file_commit(data->file);
	exmode_cmd_quit(data);
}

static void
exmode(struct inputline_data *inpline, void *hookdata)
{
	struct fileshow_priv *data = hookdata;
	char *cmd = inpline->buf;
	int len = inpline->buf_len;

	/* Trim leading/trailing whitespaces */
	while (isspace(*cmd))
		cmd++, len--;
	while (isspace(cmd[len - 1]) && len > 0)
		len--;

	if (!strcmp(cmd, "q") || !strcmp(cmd, "quit")) {
		exmode_cmd_quit(data);
	} else if (!strcmp(cmd, "x") || !strcmp(cmd, "exit")) {
		exmode_cmd_exit(data);
	} else if (!strcmp(cmd, "w") || !strcmp(cmd, "write")) {
		exmode_cmd_write(data);
	} else if (!strcmp(cmd, "r") || !strcmp(cmd, "read")) {
		exmode_cmd_read(data);
	} else if ((!strcmp(cmd, "!") || !strcmp(cmd, "pipe")) && data-> mode == MODE_VISUAL) {
		exmode_cmd_pipe(data);
	} else if (!strcmp(cmd, "s") || !strcmp(cmd, "substitute")) {
		exmode_cmd_subst(data);
	} else if (!strcmp(cmd, "S") || !strcmp(cmd, "substall")) {
		exmode_cmd_Subst(data);
	} else if (!strcmp(cmd, "swp")) {
		exmode_cmd_swp(data);
	} else if (!strcmp(cmd, "ie") || !strcmp(cmd, "ieval")) {
		exmode_cmd_ieval(data);
	} else if (!strcmp(cmd, "re") || !strcmp(cmd, "reval")) {
		exmode_cmd_reval(data);
	} else if (!strcmp(cmd, "pe") || !strcmp(cmd, "peval")) {
		exmode_cmd_peval(data);
	} else if (!strcmp(cmd, "width")) {
		exmode_cmd_width(data);
	} else {
		errmsg("Invalid command");
	}
}


/* The following MESS will hopefully get much better when we get actions and
 * keybindings. */

static enum handler_result fileshow_common_in(struct fileshow_priv *data, int ch);

static enum handler_result
fileshow_normal_in(struct fileshow_priv *data, int ch)
{
	enum handler_result ret;

	finish_insert(data);
	ret = fileshow_common_in(data, ch);
	if (ret != EVH_PASS)
		return ret;

	switch (ch) {
		case 'G':
			data->digitpos = 0;
			set_cursor(data, file_size(data->file) - 1);
			return EVH_HOLD;

		case '0':
		case '^':
			if (!jump_relative(data, - data->cursor.pos % width))
				data->digitpos = 0;
			return EVH_HOLD;
		case '$':
			if (!jump_relative(data, width -
					   data->cursor.pos % width - 1))
				data->digitpos = 0;
			return EVH_HOLD;

		case 'h':
			if (data->column == FSC_HEX && data->digitpos > 0) {
				data->digitpos--;
			} else if (!jump_relative(data, -1) &&
				   data->column == FSC_HEX)
				data->digitpos = 1;
			return EVH_HOLD;

		case 'j':
			jump_relative(data, width);
			return EVH_HOLD;

		case 'k':
			jump_relative(data, -width);
			return EVH_HOLD;

		case 'l':
			if (data->column == FSC_HEX && data->digitpos < 1) {
				data->digitpos++;
			} else
				jump_relative(data, 1);
			return EVH_HOLD;

		case 'W':
			exmode_cmd_write(data);
			return EVH_HOLD;

		case 'Z':
			exmode_cmd_exit(data);
			return EVH_HOLD;

		case 'Q':
			exmode_cmd_quit(data);
			return EVH_HOLD;

		case ':':
			inputline_init(":", exmode, data);
			return EVH_SILENTHOLD;

		case '#':
			inputline_init("#", jump_offset, data);
			return EVH_SILENTHOLD;

		case '/':
			data->last_search_dir = SDIR_FORWARD;
			inputline_init("/", expr_search, data);
			return EVH_SILENTHOLD;

		case '?':
			data->last_search_dir = SDIR_BACK;
			inputline_init("?", expr_search, data);
			return EVH_SILENTHOLD;

		case 'n':
			if (data->last_search)
				do_search(data);
			else
				errmsg("No previous search");
			return EVH_HOLD;

		case 'N':
			data->last_search_dir = -data->last_search_dir;
			if (data->last_search)
				do_search(data);
			else
				errmsg("No previous search");
			data->last_search_dir = -data->last_search_dir;
			return EVH_HOLD;

		case 'x':
			erase_at_cursor(data, 1);
			return EVH_HOLD;

		case 'X':
			if (data->cursor.pos > 0) {
				jump_relative(data, -1);
				erase_at_cursor(data, 1);
			}
			return EVH_HOLD;

		case 'v':
			if (data->mode == MODE_VISUAL) {
				data->mode = MODE_NORMAL;
			} else {
				data->mode = MODE_VISUAL;
				data->visual_start = data->cursor.pos;
			}
			return EVH_HOLD;

		case '\033':
			if (data->mode == MODE_VISUAL)
				data->mode = MODE_NORMAL;
			return EVH_HOLD;

		case 'y':
			if (data->mode != MODE_VISUAL) {
				errmsg("No region selected");
				return EVH_SILENTHOLD;
			}
			clip_yank(data);
			data->mode = MODE_NORMAL;
			return EVH_HOLD;

		case 'd':
			if (data->mode != MODE_VISUAL) {
				errmsg("No region selected");
				return EVH_SILENTHOLD;
			}
			clip_delete(data);
			data->mode = MODE_NORMAL;
			return EVH_HOLD;

		case 'p':
			if (data->mode != MODE_VISUAL)
				file_move_relative(&data->cursor, 1);
			/* fall through */
		case 'P':
			if (data->mode == MODE_VISUAL) {
				clip_swap(data);
				data->mode = MODE_NORMAL;
			} else {
				clip_put(data);
				file_move_relative(&data->cursor, -1);
			}
			return EVH_HOLD;

		case 'o':
			clip_overwrite(data);
			if (data->mode == MODE_VISUAL)
				data->mode = MODE_NORMAL;
			return EVH_HOLD;

		case 'i':
			if (data->mode == MODE_INSERT) {
				finish_insert(data);
				data->mode = MODE_REPLACE;
			} else
				data->mode = MODE_INSERT;
			return EVH_HOLD;

		case 'e':
		case 'R':
			data->mode = MODE_REPLACE;
			return EVH_HOLD;

		case 'g':
		case 'r':
		case 'm':
		case '\'':
		case '"':
			return EVH_XPREFIX;
	}

	return EVH_PASS;
}

static enum handler_result
fileshow_normal_g_in(struct fileshow_priv *data, int ch)
{
	switch (ch) {
		case 'g':
			return fileshow_normal_in(data, KEY_HOME);
		case KEY_ENTER:
			return fileshow_normal_in(data, '#');
	}

	return EVH_PASS;
}

static void
hexdigit_in(struct fileshow_priv *data, int ch, int *byte)
{
	static const char hx[] = "0123456789abcdef";
	int nibble;

	nibble = strchr(hx, ch) - hx;
	assert(nibble < 16);
	if (data->digitpos == 0) {
		*byte = (data->curbyte & 0xf)  | (nibble << 4);
	} else {
		*byte = (data->curbyte & 0xf0) | nibble;
	}
	data->digitpos++;
}

static enum handler_result
fileshow_normal_r_in(struct fileshow_priv *data, int ch)
{
	enum handler_result res = EVH_PASS;
	int byte = -1;

	if (data->column == FSC_HEX) {
		if (isxdigit(ch)) {
			hexdigit_in(data, tolower(ch), &byte);
			if (data->digitpos > 1) {
				data->digitpos = 0;
				res = EVH_HOLD;
			} else {
				/* Keep @xprefix for the second digit. */
				res = EVH_CUSTOM_XPREFIX;
			}

		} else if (ch == KEY_BACKSPACE && data->digitpos > 0) {
			data->digitpos--;
			res = EVH_CUSTOM_XPREFIX;
		} else if (ch == '\r' || ch == '\033') {
			/* Cancel the replace. */
			data->digitpos = 0;
			res = EVH_HOLD;
		} else {
			/* Persist until the user types something sensible. */
			res = EVH_CUSTOM_XPREFIX;
		}

	} else {
		byte = ch;
		res = EVH_HOLD;
	}

	if (byte >= 0) {
		if (data->mode == MODE_VISUAL) {
			blockoff_t base = NULL_BLOCKOFF;
			size_t len = visual_extents(data, &base);
			file_set_bytes(data->file, &base, byte, len);
			file_put_blockoff(&base);
		} else {
			file_set_byte(data->file, &data->cursor, byte);
		}
		data->curbyte = byte;
	}

	return res;
}

static enum handler_result
fileshow_normal_m_in(struct fileshow_priv *data, int ch)
{
	int mark = ch2mark(ch);
	if (mark >= 0)
		file_dup2_blockoff(&data->cursor, &data->file->marks[mark]);
	else
		errmsg("Invalid mark");
	return EVH_SILENTHOLD;
}

static enum handler_result
fileshow_normal_Qq_in(struct fileshow_priv *data, int ch)
{
	int mark = ch2mark(ch);
	if (mark >= 0) {
		if (is_a_blockoff(&data->file->marks[mark]))
			set_cursor(data, data->file->marks[mark].pos);
		else
			errmsg("No such mark");
	} else {
		errmsg("Invalid mark");
	}
	return EVH_HOLD;
}

static enum handler_result
fileshow_normal_QQ_in(struct fileshow_priv *data, int ch)
{
	char reg = ch2reg(ch);
	if (reg >= 0) {
		data->reg = reg;
	} else {
		errmsg("Invalid register");
	}
	return EVH_SILENTHOLD;
}

static enum handler_result
fileshow_byte_in(struct fileshow_priv *data, int ch)
{
	enum handler_result ret = EVH_PASS;
	bool insert;
	int cursmove;
	int byte = -1;

	if (ch == '\033') {
		finish_insert(data);
		data->mode = MODE_NORMAL;
		return EVH_HOLD;
	}

	ret = fileshow_common_in(data, ch);
	if (ret != EVH_PASS)
		return ret;

	insert = (data->mode == MODE_INSERT && data->cursor.pos < OFF_MAX);

	if (insert && !is_a_blockoff(&data->insert)) {
		file_insert_begin(data->file, &data->cursor, &data->insert);
		data->digitpos = 0;
		if (data->offset.pos == data->cursor.pos) {
			file_dup2_blockoff(&data->insert, &data->offset);
			update_idmark(data);
		}
	}

	cursmove = 0;
	if (data->column == FSC_HEX) {
		if (isxdigit(ch)) {
			if (insert && data->digitpos == 0)
				data->curbyte = 0;
			hexdigit_in(data, tolower(ch), &byte);
			if (data->digitpos > 1) {
				data->digitpos = 0;
				cursmove = 1;
			}
			ret = EVH_HOLD;
		}
	} else {
		cursmove = 1;
		byte = ch;
		ret = EVH_HOLD;
	}

	if (byte < 0)
		return ret;

	if (insert) {
		if (data->column != FSC_HEX) {
			file_insert_byte(data->file, &data->insert, byte);
		} else if (data->digitpos > 0) {
			file_dup2_blockoff(&data->insert, &data->cursor);
			file_insert_byte(data->file, &data->insert, byte);
		} else {
			file_set_byte(data->file, &data->cursor, byte);
			file_move_relative(&data->cursor, 1);
		}
		data->curbyte = byte;

		if (data->cursor.pos - ssize >= data->offset.pos)
			slide_viewport(data, width);
		else
			assert(data->cursor.pos >= data->offset.pos);
	} else {
		file_set_byte(data->file, &data->cursor, byte);
		data->curbyte = byte;

		jump_relative(data, cursmove);
	}

	return ret;
}

static enum handler_result
fileshow_common_in(struct fileshow_priv *data, int ch)
{
	int normal_ch;

	switch (ch) {
		case KEY_NPAGE:
		case 'F' - 'A' + 1: /* ctrl-F */
			slide_viewport(data, ssize - width);
			return EVH_HOLD;

		case KEY_PPAGE:
		case 'B' - 'A' + 1: /* ctrl-B */
			slide_viewport(data, -ssize + width);
			return EVH_HOLD;

		case 'E' - 'A' + 1: /* ctrl-E */
			slide_viewport(data, width);
			return EVH_HOLD;

		case 'Y' - 'A' + 1: /* ctrl-Y */
			slide_viewport(data, -width);
			return EVH_HOLD;

		case KEY_HOME:
			finish_insert(data);
			set_viewport(data, 0);
			file_dup2_blockoff(&data->offset, &data->cursor);
			data->digitpos = 0;
			return EVH_HOLD;

		case KEY_END:
			normal_ch = 'G'; break;

		case '\t':
			finish_insert(data);
			data->column ^= 1;
			return EVH_HOLD;

		case KEY_IC:
			normal_ch = 'i'; break;

		case KEY_DC:
			normal_ch = 'x'; break;

		case KEY_BACKSPACE:
			normal_ch = (data->mode == MODE_INSERT
				     ? 'X' : 'h');
			break;

		case KEY_LEFT:
			normal_ch = 'h'; break;

		case KEY_DOWN:
			normal_ch = 'j'; break;

		case KEY_UP:
			normal_ch = 'k'; break;

		case KEY_RIGHT:
			normal_ch = 'l'; break;

		case KEY_F(2):
			normal_ch = 'W'; break;

		case KEY_F(10):
			normal_ch = 'Z'; break;

		default:
			return EVH_PASS;
	}

	return fileshow_normal_in(data, normal_ch);
}

static enum handler_result
fileshow_handler(struct ui_component *comp, const struct ui_event *event)
{
	struct fileshow_priv *data = comp->data;
	enum handler_result res = EVH_PASS;

	switch (event->type) {
		case EV_REDRAW:
			fileshow_redraw(comp);
			break;
		case EV_KEYBOARD:
		{
			int ch = event->v.keyboard.ch;

			if (data->mode == MODE_NORMAL || data->mode == MODE_VISUAL) {
				if (xprefix == 'g') {
					res = fileshow_normal_g_in(data, ch);
				} else if (xprefix == 'r') {
					res = fileshow_normal_r_in(data, ch);
				} else if (xprefix == 'm') {
					res = fileshow_normal_m_in(data, ch);
				} else if (xprefix == '\'') {
					res = fileshow_normal_Qq_in(data, ch);
				} else if (xprefix == '"') {
					res = fileshow_normal_QQ_in(data, ch);
				} else {
					res = fileshow_normal_in(data, ch);
				}
			} else
				res = fileshow_byte_in(data, ch);

			if (res != EVH_PASS && res != EVH_SILENTHOLD)
				fileshow_redraw(comp);
			break;
		}
		case EV_DONE:
			fileshow_done(comp);
			break;
		default:
			fprintf(stderr, "Bug: fileshow_handler E.T. %d\n", event->type);
			break;
	}

	return res;
}
