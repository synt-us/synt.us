/* The main drawing interface */
/* $Id$ */

/*
 * hed - Hexadecimal editor
 * Copyright (C) 2004  Petr Baudis <pasky@ucw.cz>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef HED__TERM_TERM_H
#define HED__TERM_TERM_H


/* Initialize the terminal. */
void term_init(void);

/* Deinitialize the terminal. */
void term_done(void);


/* Wipe the terminal screen. */
void term_cls(void);

/* Redraw the terminal. */
void term_redraw(void);


/* Color type; it's an equivalence relation, mathematically. */
typedef short term_color;

/* These colors are defined by curses. */
#include <curses.h>
/* COLOR_BLACK */
/* COLOR_RED */
/* COLOR_GREEN */
/* COLOR_YELLOW */
/* COLOR_BLUE */
/* COLOR_MAGENTA */
/* COLOR_CYAN */
/* COLOR_WHITE */

#define COLOR_OFS_BG COLOR_BLACK
#define COLOR_OFS_FG COLOR_YELLOW
#define COLOR_OFS_BOLD 1
#define COLOR_OFS 1

#define COLOR_STATUS_BG COLOR_BLACK
#define COLOR_STATUS_FG COLOR_WHITE
#define COLOR_STATUS_BOLD 0
#define COLOR_STATUS 2

#define COLOR_MODE_BG COLOR_BLACK
#define COLOR_MODE_FG COLOR_WHITE
#define COLOR_MODE_BOLD 1
#define COLOR_MODE 3

#define COLOR_VISUAL_BG COLOR_WHITE
#define COLOR_VISUAL_FG COLOR_BLACK
#define COLOR_VISUAL_BOLD 0
#define COLOR_VISUAL 4

#define COLOR_ERROR_BG COLOR_BLACK
#define COLOR_ERROR_FG COLOR_RED
#define COLOR_ERROR_BOLD 1
#define COLOR_ERROR 5

#define COLOR_DIRTY_BG COLOR_BLACK
#define COLOR_DIRTY_FG COLOR_RED
#define COLOR_DIRTY_BOLD 1
#define COLOR_DIRTY 6

#define COLOR_UNDIRTY_BG COLOR_BLUE
#define COLOR_UNDIRTY_FG COLOR_RED
#define COLOR_UNDIRTY_BOLD 1
#define COLOR_UNDIRTY 7

/* Keep this a bitmap:
 *   bit 0      0 .. inside file
 *              1 .. outside file
 *   bit 1      0 .. hex
 *              1 .. ASCII
 *   bit 2      0 .. normal
 *              1 .. under cursor
 */

#define COLOR_DATA_OUTSIDE	1
#define COLOR_DATA_ASCII	2
#define COLOR_DATA_CURSOR	4

#define COLOR_DATA_BASE		8

#define COLOR_HEX_BG COLOR_BLACK
#define COLOR_HEX_FG COLOR_WHITE
#define COLOR_HEX_BOLD 0
#define COLOR_HEX	(COLOR_DATA_BASE)

#define COLOR_UNHEX_BG COLOR_BLUE
#define COLOR_UNHEX_FG COLOR_WHITE
#define COLOR_UNHEX_BOLD 0
#define COLOR_UNHEX	(COLOR_DATA_BASE | COLOR_DATA_OUTSIDE)

#define COLOR_ASC_BG COLOR_BLACK
#define COLOR_ASC_FG COLOR_GREEN
#define COLOR_ASC_BOLD 1
#define COLOR_ASC	(COLOR_DATA_BASE | COLOR_DATA_ASCII)

#define COLOR_UNASC_BG COLOR_BLUE
#define COLOR_UNASC_FG COLOR_GREEN
#define COLOR_UNASC_BOLD 1
#define COLOR_UNASC	(COLOR_DATA_BASE | COLOR_DATA_ASCII | COLOR_DATA_OUTSIDE)

#define COLOR_CURHEX_BG COLOR_BLACK
#define COLOR_CURHEX_FG COLOR_WHITE
#define COLOR_CURHEX_BOLD 1
#define COLOR_CURHEX	(COLOR_DATA_BASE | COLOR_DATA_CURSOR)

#define COLOR_CURUNHEX_BG COLOR_BLUE
#define COLOR_CURUNHEX_FG COLOR_WHITE
#define COLOR_CURUNHEX_BOLD 1
#define COLOR_CURUNHEX	(COLOR_DATA_BASE | COLOR_DATA_CURSOR | COLOR_DATA_OUTSIDE)

#define COLOR_CURASC_BG COLOR_BLACK
#define COLOR_CURASC_FG COLOR_YELLOW
#define COLOR_CURASC_BOLD 1
#define COLOR_CURASC	(COLOR_DATA_BASE | COLOR_DATA_CURSOR | COLOR_DATA_ASCII)

#define COLOR_CURUNASC_BG COLOR_BLUE
#define COLOR_CURUNASC_FG COLOR_YELLOW
#define COLOR_CURUNASC_BOLD 1
#define COLOR_CURUNASC	(COLOR_DATA_BASE | COLOR_DATA_CURSOR | COLOR_DATA_ASCII | COLOR_DATA_OUTSIDE)


/* Set the given color to be used for further drawing. */
static void term_set_color(term_color color);
/* Get the currently set color. */
static term_color term_get_color(void);


/* Move the cursor around to the given position. */
void term_goto_cursor(int x, int y);

/* Get window dimensions. */
int term_get_max_x(void);
int term_get_max_y(void);

/* Clear the given line. Can move cursor around. */
void term_clear_line(int y);


/* Put string on the screen at the current cursor position using
 * the current color. This moves the cursor position to the end of
 * the string. */
void term_put_string(const char *str);

/* Put character on the screen with everything current and moving
 * the cursor position ahead by one. */
void term_put_char(const char chr);

/* Put string on the screen at the given position with the given
 * attributes; restores the original color, not cursor position
 * afterwards. */
static void term_print_string(int x, int y, term_color color, const char *str);

/* Put char on the screen at the given position with the given
 * attributes; restores the original color, not cursor position. */
static void term_print_char(int x, int y, term_color color, const char chr);


/* Get a character from the terminal. */
int term_get_char(void);



/**** Inline functions and such. */

extern int bolds[64];

static inline void
term_set_color(term_color color)
{
	if (bolds[color]) attron(A_BOLD); else attroff(A_BOLD);
	color_set(color, NULL);
}

static inline term_color
term_get_color(void)
{
	term_color color;
	attr_t attrs;
	attr_get(&attrs, &color, NULL);
	return color;
}

static inline void
term_print_string(int x, int y, term_color color, const char *str)
{
	term_color orig = term_get_color();
	term_set_color(color);
	mvaddstr(y, x, str);
	term_set_color(orig);
}

static inline void
term_print_char(int x, int y, term_color color, const char chr)
{
	term_color orig = term_get_color();
	term_set_color(color);
	mvaddch(y, x, chr);
	term_set_color(orig);
}

#endif
