/* $Id$ */

/*
 * hed - Hexadecimal editor
 * Copyright (C) 2004  Petr Baudis <pasky@ucw.cz>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/*
 * `There's only stars, as I thought,' he said. Then he gave a low gasp, for
 * the stars went out. As if a dark veil had been withdrawn, the Mirror grew
 * grey, and then clear. There was sun shining, and the branches of trees were
 * waving and tossing in the wind.
 */

#include "config.h"

#include <curses.h>
#include <stdlib.h>

#include "hed.h"

#include "term/term.h"


static WINDOW *scr;
int bolds[64] = { 0 };

/* Initialize the terminal. */
void
term_init(void)
{
#define INIT_PAIR(PN_)					      \
	[ ( COLOR_ ## PN_ ) - 1 ] = {			      \
	  ( COLOR_ ## PN_ ## _FG ), ( COLOR_ ## PN_ ## _BG ), \
	  ( COLOR_ ## PN_ ## _BOLD ) }
	static const struct {
		short fg,  bg;
		bool bold;
	} pairs[] = {
		INIT_PAIR(OFS),
		INIT_PAIR(STATUS),
		INIT_PAIR(MODE),
		INIT_PAIR(VISUAL),
		INIT_PAIR(ERROR),
		INIT_PAIR(DIRTY),
		INIT_PAIR(UNDIRTY),
		INIT_PAIR(HEX),
		INIT_PAIR(UNHEX),
		INIT_PAIR(ASC),
		INIT_PAIR(UNASC),
		INIT_PAIR(CURHEX),
		INIT_PAIR(CURUNHEX),
		INIT_PAIR(CURASC),
		INIT_PAIR(CURUNASC),
	};
#undef INIT_PAIR
	int i;

	scr = initscr();
	cbreak(); noecho(); nonl();
	intrflush(scr, FALSE);
	keypad(scr, TRUE);

	start_color();
	for (i = 0; i < sizeof(pairs) / sizeof(pairs[0]); ++i) {
		init_pair(i + 1, pairs[i].fg, pairs[i].bg);
		bolds[i + 1] = pairs[i].bold;
	}

	refresh();
}

/* Deinitialize the terminal. */
void
term_done(void)
{
	endwin();
}


/* Wipe the terminal screen. */
void
term_cls(void)
{
	erase();
}

/* Redraw the terminal. */
void term_redraw(void)
{
	refresh();
}


/* Move the cursor around to the given position. */
void
term_goto_cursor(int x, int y)
{
	move(y, x);
}

/* Get window dimensions. */
int
term_get_max_x(void)
{
	int x, y;
	getmaxyx(stdscr, y, x);
	return x;
}

int
term_get_max_y(void)
{
	int x, y;
	getmaxyx(stdscr, y, x);
	return y;
}

/* Clear the given line. Can move cursor around. */
void
term_clear_line(int y)
{
	move(y, 0);
	clrtoeol();
}


/* Put string on the screen at the current cursor position using
 * the current color. This moves the cursor position to the end of
 * the string. */
void
term_put_string(const char *str)
{
	addstr(str);
}

/* Put character on the screen with everything current and moving
 * the cursor position ahead by one. */
void
term_put_char(const char chr)
{
	addch(chr);
}


/* Get a character from the terminal. */
int
term_get_char(void)
{
	return getch();
}
