/* $Id$ */

#ifndef HED__UTIL_NUMBERS_H
#define HED__UTIL_NUMBERS_H

/*
 * Bilbo was going to be eleventy-one, 111, a rather curious number and a very
 * respectable age for a hobbit (the Old Took himself had only reached 130);
 * and Frodo was going to be thirty-three, 33, an important number: the date
 * of his 'coming of age'.
 */


/* Maximal value of off_t. (off_t is always signed) */
#define OFF_MAX (off_t) ((1ULL << (sizeof(off_t) * 8 - 1)) - 1)

/* typedef uoff_t as an unsigned type with the same size as off_t */
#define _mk_t(type,bits) type ## bits ## _t
#define _mk_uint_t(bits) _mk_t(uint, bits)
typedef _mk_uint_t(_FILE_OFFSET_BITS) uoff_t;
#undef _mk_t
#undef _mk_uint_t

/* The biggest possible integer type. */
typedef BINT_TYPE bint;
typedef unsigned BINT_TYPE ubint;

/* Minimax. */
static bint min(const bint a, const bint b);
static bint max(const bint a, const bint b);

/* Find the highest bit. */
static int bitsize(ubint x);



/**** Inline functions and such. */

static inline bint
min(const bint a, const bint b)
{
	return a < b ? a : b;
}

static inline bint
max(const bint a, const bint b)
{
	return a > b ? a : b;
}

static inline int
bitsize(ubint x)
{
	int r = 0;
	/* FIXME: only up to 64bits */
	if (x & 0xffffffff00000000ULL) { x >>= 32; r += 32; }
	if (x & 0x00000000ffff0000ULL) { x >>= 16; r += 16; }
	if (x & 0x000000000000ff00ULL) { x >>=  8; r +=  8; }
	if (x & 0x00000000000000f0ULL) { x >>=  4; r +=  4; }
	if (x & 0x000000000000000cULL) { x >>=  2; r +=  2; }
	if (x & 0x0000000000000002ULL) {           r +=  1; }
	return r;
}

#endif
