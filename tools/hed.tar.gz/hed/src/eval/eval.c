/* $Id$ */

/*
 * hed - Hexadecimal editor
 * Copyright (C) 2004  Petr Baudis <pasky@ucw.cz>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/*
 * 'You see: Mr. Drogo, he married poor Miss Primula Brandybuck. She was our
 * Mr. Bilbo's first cousin on the mother's side (her mother being the youngest
 * of the Old Took's daughters); and Mr. Drogo was his second cousin. So Mr.
 * Frodo is his first _and_ second cousin, once removed either way, as the
 * saying is, if you follow me.
 */

#include "config.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "hed.h"

#include "config/config.h"
#include "eval/eval.h"
#include "util/lists.h"


/* This is really just trivial implementation. */

struct atom {
	struct list_head list;

	int len; // Spans over n bytes; -1 == auto (defaults to 1 at root)

	enum atom_type {
		ATOM_UN,
		ATOM_BIN,
		ATOM_BYTESTR,
		ATOM_NUMBER,
		ATOM_REGISTER,
		ATOM_MARK,
		ATOM_T_MAX
	} type;

	unsigned char *bytes;	// Constant bytestring if non-NULL
};

typedef void (*atom_evaluator)(struct expression *expr, struct atom *atom, unsigned char *scramble);
static void atom_un(struct expression *expr, struct atom *atom, unsigned char *scramble);
static void atom_bin(struct expression *expr, struct atom *atom, unsigned char *scramble);
static void atom_number(struct expression *expr, struct atom *atom, unsigned char *scramble);
static void atom_register(struct expression *expr, struct atom *atom, unsigned char *scramble);
static void atom_mark(struct expression *expr, struct atom *atom, unsigned char *scramble);
static atom_evaluator evals[ATOM_T_MAX] = {
	atom_un, atom_bin, NULL, atom_number, atom_register, atom_mark
};

typedef void (*atom_free)(void *atom);
static void free_bin(void *p);
static atom_free frees[ATOM_T_MAX] = {
	free, free_bin, free, free, free, free
};

struct atom_un {
	struct atom a;
	enum atom_un_op {
		AUO_NEG,
	} op;
	struct atom *atom;
};

struct atom_bin {
	struct atom a;
	enum atom_bin_op {
		ABO_OR,
		ABO_AND,
		ABO_XOR,
		ABO_PLUS,
		ABO_MINUS,
		ABO_MUL,
		ABO_DIV,
		ABO_MOD,
		ABO_SHL,
		ABO_SHR,
	} op;
	struct atom *atom1;
	struct atom *atom2;
};

struct atom_bytestr {
	struct atom a;
	unsigned char bytes[0]; /* [len] */
};

struct atom_number {
	struct atom a;
	ubint num; /* maximal size */
};

struct expression;

struct atom_register {
	struct atom a;
	char reg;
	struct expression *offset;
};

struct atom_mark {
	struct atom a;
	char mark;
};

struct expression {
	struct list_head atoms;
	int len;
	reg_callback reg_cb;
	mark_callback mark_cb;
	void *cb_data;
	int cb_pos;
	bool is_const;
};


static void
free_atom(struct atom *atom)
{
	frees[atom->type](atom);
}


static char
unhex(char x)
{
	static const char hx[] = "0123456789abcdef";
	return strchr(hx, tolower(x)) - hx;
}

static void
skip_white(char **sexpr)
{
	while (isspace(**sexpr))
		(*sexpr)++;
}

static struct atom *atom_parse(char **sexpr);
static struct expression *expr_compile_till(char **sexpr, char till);

static struct atom *
val_parse(char **sexpr)
{
	struct atom *a = NULL;

	skip_white(sexpr);

	if (**sexpr == '(') {
		(*sexpr)++;
		a = atom_parse(sexpr);

	} else if (**sexpr == '~') {
		struct atom *sa;
		(*sexpr)++;
		sa = val_parse(sexpr);
		if (sa) {
			a = calloc(1, sizeof(struct atom_un));
			a->len = sa->len;
			a->type = ATOM_UN;
			((struct atom_un *) a)->atom = sa;
		}

	} else if (**sexpr == '"') {
		char reg;

		(*sexpr)++;
		reg = **sexpr;
		(*sexpr)++;

		a = calloc(1, sizeof(struct atom_register));
		a->len = -1;
		a->type = ATOM_REGISTER;
		((struct atom_register *) a)->reg = reg;

		if (**sexpr == '[') {
			(*sexpr)++;
			((struct atom_register *) a)->offset = expr_compile_till(sexpr, ']');
			(*sexpr)++;
		}
	} else if (**sexpr == '@') {
		char mark;

		(*sexpr)++;
		mark = **sexpr;
		(*sexpr)++;

		a = calloc(1, sizeof(struct atom_mark));
		a->len = sizeof(off_t);
		a->type = ATOM_MARK;
		((struct atom_mark *) a)->mark = mark;
	} else if (**sexpr == '\'') {
		char *base;
		int i = 0;

		(*sexpr)++;
		base = *sexpr;
		while (**sexpr && **sexpr != '\'') {
			if (**sexpr == '\\') {
				(*sexpr)++;
				if (!**sexpr)
					return NULL;
			}
			i++;
			(*sexpr)++;
		}

		a = calloc(1, sizeof(struct atom_bytestr) + i);
		a->len = i;
		a->type = ATOM_BYTESTR;
		for (i = 0; base < *sexpr; i++, base++) {
			if (*base == '\\')
				base++;
			((struct atom_bytestr *) a)->bytes[i] = *base;
		}
		a->bytes = ((struct atom_bytestr *) a)->bytes;
		(*sexpr)++;

	} else if (**sexpr == 'x') {
		char *base;
		int i;

		(*sexpr)++;
		base = *sexpr;
		while (isxdigit(**sexpr))
			(*sexpr)++;

		i = *sexpr - base;
		a = calloc(1, sizeof(struct atom) + (i+1)/2);
		a->len = (i + 1) / 2;
		a->type = ATOM_BYTESTR;
		for (i = 0; base < *sexpr; i++, base++) {
			// l33t
			((struct atom_bytestr *) a)->bytes[i / 2] |= unhex(*base) << ((1-i%2)*4);
		}
		a->bytes = ((struct atom_bytestr *) a)->bytes;

	} else if (isdigit(**sexpr)) {
		char *base = *sexpr;
		ubint num = strtoull(*sexpr, sexpr, 0);
		assert(sizeof(ubint) == sizeof(unsigned long long));
		// ...or fix me to use something better than strtoull()!
		assert(*sexpr > base);

		a = calloc(1, sizeof(struct atom_number));
		if (base[0] == '0' && base[1] == 'x') {
			/* Take leading zeros of hex numbers into account */
			a->len = (*sexpr - base - 2 + 1) / 2;
		} else {
			/* Whatever fits */
			a->len = 1 + bitsize(num) / 8;
		}
		a->type = ATOM_NUMBER;
		((struct atom_number *) a)->num = num;
	}

	if (**sexpr == '{') {
		int len;
		(*sexpr)++;
		len = strtoull(*sexpr, sexpr, 0);
		if (**sexpr != '}') {
			free_atom(a);
			return NULL;
		}
		if (a->type != ATOM_NUMBER || a->len > sizeof(ubint)) {
			/* Not supported yet */
			free_atom(a);
			return NULL;
		}
		a->len = len;
		(*sexpr)++;
	}
	return a;
}

static struct atom *
atom_lparse(char **sexpr, struct atom *sa1)
{
	struct atom *a, *sa2;
	char bopc[] = "|&^+-*/%<>"; // in atom_bin_op order
	char *bop;

	skip_white(sexpr);
	if (!**sexpr)
		return sa1;
	if (**sexpr == ')') {
		(*sexpr)++;
		return sa1; // *SLAMM*
	}
	bop = strchr(bopc, **sexpr);
	if (!bop)
		return sa1;
	(*sexpr)++;
	if (*bop == '<' || *bop == '>') {
		if (*(*sexpr)++ != *bop)
			return NULL;
	}
	sa2 = val_parse(sexpr);
	if (**sexpr == ')')
		(*sexpr)++;
	if (!sa2)
		//fprintf(stderr, "parse error at <%s>\n", *sexpr);
		return NULL;

	if (sa1->len == -1)
		sa1->len = sa2->len;
	else if (sa2->len == -1)
		sa2->len = sa1->len;
	/* Note that BOTH may be -1, but that's ok */

	a = calloc(1, sizeof(struct atom_bin));
	a->len = max(sa1->len, sa2->len);
	a->type = ATOM_BIN;
	((struct atom_bin *) a)->op = bop - bopc;
	((struct atom_bin *) a)->atom1 = sa1;
	((struct atom_bin *) a)->atom2 = sa2;
	/* Try to expand the epxression */
	return atom_lparse(sexpr, a) ? : a;
}

static struct atom *
atom_parse(char **sexpr)
{
	struct atom *a, *sa1;

	sa1 = val_parse(sexpr);
	if (!sa1) {
		//fprintf(stderr, "parse error at <%s>\n", *sexpr);
		(*sexpr)++; // no luck, maybe next char
		return NULL;
	}
	a = atom_lparse(sexpr, sa1);
	if (!a) {
		free_atom(sa1);
		return NULL;
	}
	return a;
}

static struct expression *
expr_compile_till(char **sexpr, char till)
{
	struct expression *expr = calloc(1, sizeof(struct expression));
	INIT_LIST_HEAD(&expr->atoms);
	while (**sexpr != till) {
		struct atom *a = atom_parse(sexpr);
		if (a) {
			list_add_tail(&a->list, &expr->atoms);
			if (a->len == -1)
				a->len = 1;
			expr->len += a->len;
		}
	}
	if (list_empty(&expr->atoms)) {
		free(expr);
		expr = NULL;
	}
	return expr;
}

struct expression *
expr_compile(char *sexpr)
{
	return expr_compile_till(&sexpr, '\0');
}


int
expr_len(struct expression *expr)
{
	assert(expr && expr->len >= 0);
	return expr->len;
}


/* FIXME: These two assume LE bytesex */

ubint
bytestr2num(unsigned char *bytestr, int len)
{
	ubint num = 0;
	int i;
	assert(len <= sizeof(ubint));
	for (i = 0; i < len; i++)
		num |= (ubint) bytestr[i] << ((len - i - 1) * 8);
	return num;
}

void
num2bytestr(unsigned char *bytestr, int len, ubint num)
{
	assert(len <= sizeof(ubint));
	while (len--)
		*(bytestr++) = (num >> (len * 8)) & 0xff;
}


static void
atom_eval(struct expression *expr, struct atom *parent, struct atom *atom, unsigned char *scramble)
{
	if (parent && atom->len == -1)
		atom->len = parent->len;

	if (atom->bytes)
		memcpy(scramble, atom->bytes, atom->len);
	else {
		expr->is_const = false;
		evals[atom->type](expr, atom, scramble);
	}
}

static void
atom_un(struct expression *expr, struct atom *atom, unsigned char *scramble)
{
	struct atom_un *data = (struct atom_un *) atom;
	int i;
	assert(data);
	assert(data->op == AUO_NEG);
	assert(data->atom);
	atom_eval(expr, atom, data->atom, scramble);
	for (i = 0; i < atom->len; i++)
		scramble[i] = ~scramble[i];
}

static void
atom_bin(struct expression *expr, struct atom *atom, unsigned char *scramble)
{
	struct atom_bin *data = (struct atom_bin *) atom;
	unsigned char *s1, *s2;
	int i; ubint n1, n2;
	assert(data);
	assert(data->atom1 && data->atom2);
	assert(data->atom1->len <= atom->len && data->atom2->len <= atom->len);
	s1 = calloc(1, atom->len);
	s2 = calloc(1, atom->len);
	atom_eval(expr, atom, data->atom1, s1);
	atom_eval(expr, atom, data->atom2, s2);
	switch (data->op) {
		case ABO_OR:
			for (i = 0; i < atom->len; i++) {
				scramble[i] = s1[i] | s2[i];
			}
			break;
		case ABO_AND:
			for (i = 0; i < atom->len; i++)
				scramble[i] = s1[i] & s2[i];
			break;
		case ABO_XOR:
			for (i = 0; i < atom->len; i++)
				scramble[i] = s1[i] ^ s2[i];
			break;
		case ABO_PLUS:
			n1 = bytestr2num(s1, data->atom1->len);
			n2 = bytestr2num(s2, data->atom2->len);
			num2bytestr(scramble, atom->len, n1 + n2);
			break;
		case ABO_MINUS:
			n1 = bytestr2num(s1, data->atom1->len);
			n2 = bytestr2num(s2, data->atom2->len);
			num2bytestr(scramble, atom->len, n1 - n2);
			break;
		case ABO_MUL:
			n1 = bytestr2num(s1, data->atom1->len);
			n2 = bytestr2num(s2, data->atom2->len);
			num2bytestr(scramble, atom->len, n1 * n2);
			break;
		case ABO_DIV:
			n1 = bytestr2num(s1, data->atom1->len);
			n2 = bytestr2num(s2, data->atom2->len);
			num2bytestr(scramble, atom->len, n1 / n2);
			break;
		case ABO_MOD:
			n1 = bytestr2num(s1, data->atom1->len);
			n2 = bytestr2num(s2, data->atom2->len);
			num2bytestr(scramble, atom->len, n1 % n2);
			break;
		case ABO_SHL:
			n1 = bytestr2num(s1, data->atom1->len);
			n2 = bytestr2num(s2, data->atom2->len);
			num2bytestr(scramble, atom->len, n1 << n2);
			break;
		case ABO_SHR:
			n1 = bytestr2num(s1, data->atom1->len);
			n2 = bytestr2num(s2, data->atom2->len);
			num2bytestr(scramble, atom->len, n1 >> n2);
			break;
		default:
			assert(0);
			break;
	}
}

static void
atom_number(struct expression *expr, struct atom *atom, unsigned char *scramble)
{
	struct atom_number *data = (struct atom_number *) atom;
	assert(data);
	assert(atom->len <= sizeof(data->num));
	num2bytestr(scramble, atom->len, data->num);
}

static void
atom_mark(struct expression *expr, struct atom *atom, unsigned char *scramble)
{
	struct atom_mark *data = (struct atom_mark *) atom;
	assert(data);
	if (expr->mark_cb) {
		expr->mark_cb(expr->cb_data, data->mark, expr->cb_pos, scramble, atom->len);
	} else {
		memset(scramble, 0, atom->len);
	}
}


static void
atom_register(struct expression *expr, struct atom *atom, unsigned char *scramble)
{
	struct atom_register *data = (struct atom_register *) atom;
	assert(data);
	if (expr->reg_cb) {
		off_t ofs = 0;
		if (data->offset) {
			unsigned char *ofs_buf = expr_eval(data->offset, expr->reg_cb, expr->mark_cb, expr->cb_data);
			if (ofs_buf) {
				ofs = bytestr2num(ofs_buf, expr_len(data->offset));
				free(ofs_buf);
			}
		}
		expr->reg_cb(expr->cb_data, data->reg, ofs, expr->cb_pos, scramble, atom->len);
	} else {
		memset(scramble, 0, atom->len);
	}
}


unsigned char *
expr_eval(struct expression *expr, reg_callback rcb, mark_callback mcb, void *data)
{
	unsigned char *buf;
	struct atom *a;
	int pos = 0;

	expr->is_const = true;
	expr->reg_cb = rcb;
	expr->mark_cb = mcb;
	expr->cb_data = data;

	assert(expr && expr->len >= 0);
	buf = malloc(expr->len);
	list_for_each_entry (a, &expr->atoms, list) {
		expr->cb_pos = pos;
		atom_eval(expr, NULL, a, buf + pos);
		pos += a->len;
	}
	assert(pos == expr->len);
	return buf;
}

bool
expr_is_const(const struct expression *expr)
{
	return expr->is_const;
}

static void
free_bin(void *p)
{
	struct atom_bin *bin = (struct atom_bin *) p;
	free_atom(bin->atom1);
	free_atom(bin->atom2);
	free(p);
}

void
expr_free(struct expression *expr)
{
	struct atom *a, *next;

	list_for_each_entry_safe (a, next, &expr->atoms, list)
		free_atom(a);
	free(expr);
}
