/* The expression evaluator */
/* $Id$ */

/*
 * hed - Hexadecimal editor
 * Copyright (C) 2004  Petr Baudis <pasky@ucw.cz>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef HED__EVAL_EVAL_H
#define HED__EVAL_EVAL_H


struct expression;

typedef void (*reg_callback)(void *data, char reg, bint ofs, int relpos, unsigned char *scramble, int len);
typedef void (*mark_callback)(void *data, char mark, int relpos, unsigned char *scramble, int len);

struct expression *expr_compile(char *sexpr);
int expr_len(struct expression *expr);
unsigned char *
expr_eval(struct expression *expr, reg_callback rcb, mark_callback mcb, void *data);
bool expr_is_const(const struct expression *expr);
void expr_free(struct expression *expr);

ubint bytestr2num(unsigned char *bytestr, int len);
void num2bytestr(unsigned char *bytestr, int len, ubint num);


#endif
