/* $Id$ */

/*
 * hed - Hexadecimal editor
 * Copyright (C) 2004  Petr Baudis <pasky@ucw.cz>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/*
 * When his eyes were in turn uncovered, Frodo looked up and caught his breath.
 * They were standing in an open space. To the left stood a great mound,
 * covered with a sward of grass as green as Spring-time in the Elder Days.
 * Upon it, as a double crown, grew two circles of trees: the outer had bark of
 * snowy white, and were leafless but beautiful in their shapely nakedness; the
 * inner were mallorn-trees of great height, still arrayed in pale gold. High
 * amid the branches of a towering tree that stood in the centre of all there
 * gleamed a white flet. At the feet of the trees, and all about the green
 * hillsides the grass was studded with small golden flowers shaped like stars.
 * Among them, nodding on slender stalks, were other flowers, white and palest
 * green: they glimmered as a mist amid the rich hue of the grass. Over all the
 * sky was blue, and the sun of afternoon glowed upon the hill and cast long
 * green shadows beneath the trees.
 */

#include "config.h"

#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>

#include "hed.h"

#include "file/tree.h"


/* Define to enable debug messages */
#undef TREE_DEBUG
#ifdef TREE_DEBUG
#define TDEBUG(x...) fprintf(stderr, x)
#else
#define TDEBUG(x...)
#endif


static void
recalc_node(struct tree *tree, struct tree_head *item)
{
	item->cover_size = item->size;
	if (is_a_node(tree, item->left)) {
		item->cover_size += item->left->cover_size;
		item->left->up = item;
	}
	if (is_a_node(tree, item->right)) {
		item->cover_size += item->right->cover_size;
		item->right->up = item;
	}
}

void
recalc_node_recursive(struct tree *tree, struct tree_head *item)
{
	while (is_a_node(tree, item)) {
		recalc_node(tree, item);
		item = item->up;
	}
}

static void
del_leaf(struct tree *tree, struct tree_head *item)
{
	list_del(&item->link);

	if (item == tree->root) {
		tree->root = null_node(tree);
		return;
	}

	assert(!is_a_node(tree, item->left) && !is_a_node(tree, item->right) &&
	       is_a_node(tree, item->up));
	if (item->up->left == item) {
		item->up->left = null_node(tree);
	} else {
		assert(item->up->right == item);
		item->up->right = null_node(tree);
	}

	item->up = null_node(tree);
}

void
del_from_tree(struct tree *tree, struct tree_head *item)
{
	unsplay(tree, item);
	del_leaf(tree, item);
}

void
recalc_del_from_tree(struct tree *tree, struct tree_head *item)
{
	struct tree_head *parent;

	/*
	 * 'I'll give your name and number to the Nazgyl,' said the soldier
	 * lowering his voice to a hiss. 'One of *them*'s in charge at the
	 * Tower now.'
	 */

	unsplay(tree, item);
	parent = item->up;
	del_leaf(tree, item);
	assert(item->size == item->cover_size);
	while (is_a_node(tree, parent)) {
		parent->cover_size -= item->size;
		parent = parent->up;
	}
}

void
insert_into_tree(struct tree *tree, struct tree_head *item,
		 struct tree_head *pos)
{
	item->up = item->left = item->right = null_node(tree);
	item->cover_size = item->size;

	splay(tree, is_a_node(tree, pos) ? pos : first_in_tree(tree));

	list_add(&item->link, &pos->link);

	if (!is_a_node(tree, pos)) {
		pos = tree->root;
		item->left = null_node(tree);
		item->right = pos;
	} else {
		assert(tree->root == pos);
		item->left = pos;
		item->right = pos->right;
		pos->right = null_node(tree);
		recalc_node(tree, pos);
	}
	if (is_a_node(tree, pos))
		pos->up = item;
	tree->root = item;
	recalc_node(tree, item);
}

void
append_to_tree(struct tree *tree, struct tree_head *item)
{
	insert_into_tree(tree, item, last_in_tree(tree));
}

struct tree_head *
find_in_tree(struct tree *tree, uoff_t offset)
{
	struct tree_head *item = null_node(tree), *nitem = tree->root;
	uoff_t pos = is_a_node(tree, nitem) && is_a_node(tree, nitem->left)
		? nitem->left->cover_size : 0;

	while (is_a_node(tree, nitem)) {
		/* We splay as we go. */
		TDEBUG("find_in_tree(%llx): %llx\n", offset, pos);
		/* rot_up(tree, nitem); */
		item = nitem;
		if (pos <= offset && offset < pos + item->size) {
			TDEBUG("find_in_tree(%llx): match - pos %llx, size %llx\n", offset, pos, item->size);
			nitem = null_node(tree);
		} else if (pos > offset) {
			TDEBUG("find_in_tree(%llx): going left\n", offset);
			nitem = item->left;
			pos -= is_a_node(tree, nitem)
				? nitem->size + (is_a_node(tree, nitem->right)
					? nitem->right->cover_size
					: 0)
				: 0;
		} else { assert(pos <= offset && pos + item->size <= offset);
			TDEBUG("find_in_tree(%llx): going right\n", offset);
			nitem = item->right;
			pos += item->size + (is_a_node(tree, nitem) &&
					     is_a_node(tree, nitem->left)
				? nitem->left->cover_size
				: 0);
			/* If we are going far too left, we must return NULL. */
			item = nitem;
		}
	}

	if (is_a_node(tree, item))
		TDEBUG("find_in_tree(%llx): chosen %llx + %llx\n", offset, pos, item->size);
	else
		TDEBUG("find_in_tree(%llx): chosen %llx - but not found\n", offset, pos);

	/* TODO: Splay as we go? */
	if (is_a_node(tree, item))
		splay(tree, item);

	return item;
}

uoff_t
tree_block_offset(struct tree *tree, struct tree_head *item)
{
	struct tree_head *up;
	uoff_t off;

	assert(is_a_node(tree, item));
	off = is_a_node(tree, item->left) ? item->left->cover_size : 0;
	while (is_a_node(tree, up = item->up)) {
		if (item == up->right)
			off += up->cover_size - item->cover_size;
		item = up;
	} 
	return off;
}

static void
update_parent(struct tree *tree, struct tree_head *old, struct tree_head *new)
{
	new->up = old->up;
	if (!is_a_node(tree, new->up)) {
		assert(tree->root == old);
		tree->root = new;
	} else {
		if (old->up->left == old) {
			new->up->left = new;
		} else { assert(old->up->right == old);
			new->up->right = new;
		}
	}
}

void
splay(struct tree *tree, struct tree_head *item)
{
	struct tree_head *item_mid, *item_top;

	assert(is_a_node(tree, item) || item == tree->root);
	assert(is_a_node(tree, tree->root) || item == tree->root);

	while (item != tree->root) {
		item_top = tree->root;

		if (item->up == item_top) {
			if (item_top->left == item) {
				item_top->left = item->right;
				item->right = item_top;
			} else { assert(item_top->right == item);
				item_top->right = item->left;
				item->left = item_top;
			}
			recalc_node(tree, item_top);
			recalc_node(tree, item);
			tree->root = item;
			item->up = null_node(tree);
			return;
		}

		/*
	 	* 'Come on, you slugs!' he cried. 'This is no time for
		* slouching.' He took a step towards them, and even in the
		* gloom he recognized the devices on their shields.
		* 'Deserting, eh?' he snarled. 'Or thinking of it? All your
		* folk should have been inside Udyn before yesterday evening.
		* You know that. Up you get and fall in, or I'll have your
	 	* numbers and report you.'
	 	*/

		assert(is_a_node(tree, item->up));

		item_mid = item->up; assert(is_a_node(tree, item_mid));
		item_top = item_mid->up; assert(is_a_node(tree, item_top));

		update_parent(tree, item_top, item);
		item_top->up = item;

		if (item_top->left == item_mid &&
		    item_mid->left == item) {
			item_mid->left = item->right;
			item->right = item_top;
		} else if (item_top->right == item_mid &&
			   item_mid->right == item) {
			/* Inverse operation. */
			item_mid->right = item->left;
			item->left = item_top;
		} else if (item_top->left == item_mid &&
			   item_mid->right == item) {
			item_top->left = item->right;
			item->right = item_top;

			item_mid->up = item;
			item_mid->right = item->left;
			item->left = item_mid;
		} else { assert(item_top->right == item_mid &&
				item_mid->left == item);
			/* Inverse operation. */
			item_top->right = item->left;
			item->left = item_top;

			item_mid->up = item;
			item_mid->left = item->right;
			item->right = item_mid;
		}

		recalc_node(tree, item_mid);
		recalc_node(tree, item_top);
		recalc_node(tree, item);
	}
}

void
unsplay(struct tree *tree, struct tree_head *item)
{
	assert(is_a_node(tree, tree->root));

	for (;;) {
		struct tree_head *item_down;

		/* TODO: If we kept track of how many items are in each
		 * subtree, we could've made an actually inteligent
		 * choice. */
		if (is_a_node(tree, item->left)) {
			item_down = item->left;
			item->left = item_down->right;
			item_down->right = item;
		} else if(is_a_node(tree, item->right)) {
			item_down = item->right;
			item->right = item_down->left;
			item_down->left = item;
		} else
			break;

		update_parent(tree, item, item_down);
		item->up = item_down;
		recalc_node(tree, item);
		recalc_node(tree, item_down);
	}
}
