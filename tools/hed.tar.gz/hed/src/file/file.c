/* $Id$ */

/*
 * hed - Hexadecimal editor
 * Copyright (C) 2004  Petr Baudis <pasky@ucw.cz>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/*
 * There hammer on the anvil smote,
 * There chisel clove, and graver wrote;
 * There forged was blade, and bound was hilt;
 * The delver mined, the mason built.
 * There beryl, pearl, and opal pale,
 * And metal wrought like fishes' mail,
 * Buckler and corslet, axe and sword,
 * And shining spears were laid in hoard.
 */

#include "config.h"

#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <linux/fs.h>	/* BLKGETSIZE and BLKGETSIZE64 */
#ifdef CONFIG_MMAP
# include <sys/mman.h>
#endif

#include "hed.h"

#include "file/file.h"

/*
 * `Piles of jewels?' said Gandalf. `No. The Orcs have often plundered Moria;
 * there is nothing left in the upper halls. And since the dwarves fled, no one
 * dares to seek the shafts and treasuries down in the deep places: they are
 * drowned in water--or in a shadow of fear.'
 */

/* TODO: Currently the file blocks allocation is not very sophisticated and
 * when the weather is bad it could probably have rather horrible results. */

#undef BLOCKS_DEBUG
#ifdef BLOCKS_DEBUG
#define BDEBUG(x...) fprintf(stderr, x)
#else
#define BDEBUG(x...)
#endif

#ifdef CONFIG_MMAP
long sys_page_size;	/* Page size (in bytes) */
#endif

static uoff_t
block_phys_size(struct file *file, struct file_block *block)
{
	struct file_block *next;

	if (block->phys_pos >= file->phys_size)
		return 0;

	next = next_block(block);
	if (!is_a_block(&file->blocks, next)) {
		assert(block_is_virtual(block));
		return 0;
	}

	return next->phys_pos - block->phys_pos;
}

#ifndef BLOCKS_DEBUG
# define dump_blocks(file)	{}
#else
static void
dump_block(int level, struct file *file, struct tree_head *node, uoff_t *cur_offset, uoff_t *cur_poffset)
{
	struct file_block *block = tree_entry(node, struct file_block, t);
	bool virtual = block_is_virtual(block);
	blockoff_t *cur;
	char t[21] = "                    ";

	if (is_a_node(&file->blocks, node->left))
		dump_block(level + 1, file, node->left, cur_offset, cur_poffset);
	if (level < 20) t[level] = '>'; else t[19] = '.';
	fprintf(stderr, "%s [%06llx] [%06llx] %c%c%c %05llx %05llx {%02x%02x%02x%02x} -- %p ^%p [%06llx]\n",
	        t, *cur_offset, *cur_poffset,
		virtual ? 'v' : ' ', block_is_inserted(block) ? 'i' : ' ',
		block_is_dirty(block) ? '*' : ' ',
		node->size, block_phys_size(file, block),
		!virtual && block->t.size > 0 ? block_data(block)[0] : 0,
		!virtual && block->t.size > 1 ? block_data(block)[1] : 0,
		!virtual && block->t.size > 2 ? block_data(block)[2] : 0,
		!virtual && block->t.size > 3 ? block_data(block)[3] : 0,
		node, is_a_node(&file->blocks, node->up) ? node->up : NULL,
		node->cover_size
		);
	list_for_each_entry (cur, &block->refs, list) {
		fprintf(stderr, "  <%p>: %llx->%p:%lx\n",
			cur, cur->pos, cur->block, cur->off);
	}
	assert(*cur_poffset == block->phys_pos);
	*cur_offset += node->size;
	*cur_poffset += block_phys_size(file, block);
	if (is_a_node(&file->blocks, node->right))
		dump_block(level + 1, file, node->right, cur_offset, cur_poffset);
	assert(node->cover_size == (is_a_node(&file->blocks, node->left) ? node->left->cover_size : 0)
	                            + (is_a_node(&file->blocks, node->right) ? node->right->cover_size : 0)
				    + node->size);
}

/* Walk the tree manually here, because foreach_block() does not provide
 * the tree structure.
 * TODO: Change this if you plan to debug any other block containers.
 */
static void
dump_blocks(struct file *file)
{
	struct file_block *first = first_block(&file->blocks);
	uoff_t cur_offset, cur_poffset;

	fprintf(stderr, "-- blocks dump --\n");
	if (is_a_block(&file->blocks, first)) {
		cur_offset = 0;
		cur_poffset = first->phys_pos;
		dump_block(0, file, file->blocks.root,
			   &cur_offset, &cur_poffset);
	}
	fprintf(stderr, "-- blocks dump end --\n");
}
#endif

static void
_file_get_blockoff(struct file *file, uoff_t offset, blockoff_t *blockoff)
{
	struct file_block *block;

	block = find_block(&file->blocks, offset);
	assert(is_a_block(&file->blocks, block));
	blockoff->pos = offset;
	blockoff->block = block;
	blockoff->off = offset - block_offset(&file->blocks, block);
	list_add(&blockoff->list, &block->refs);

	BDEBUG("Mapped %llx to %llx+%llx/%llx\n",
	       offset, offset - blockoff->off, blockoff->off, block->t.size);
}

void
file_get_blockoff(struct file *file, uoff_t offset, blockoff_t *blockoff)
{
	if (is_a_blockoff(blockoff))
		file_put_blockoff(blockoff);
	_file_get_blockoff(file, offset, blockoff);
}

void
file_dup_blockoff(blockoff_t *src, blockoff_t *dst)
{
	dst->pos = src->pos;
	dst->block = src->block;
	dst->off = src->off;
	list_add(&dst->list, &src->list);
}

void
file_dup2_blockoff(blockoff_t *src, blockoff_t *dst)
{
	if (is_a_blockoff(dst))
		file_put_blockoff(dst);
	file_dup_blockoff(src, dst);
}

bool
file_pos_after_erase(const struct file *file, blockoff_t *blockoff)
{
	struct file_block *block, *prev;

	if (blockoff->off)
		return false;

	block = blockoff->block;
	prev = prev_block(block);
	if (is_a_block(&file->blocks, prev)) {
		uoff_t prevend = prev->phys_pos;
		if (!block_is_inserted(prev))
			prevend += prev->t.size;
		return block->phys_pos > prevend;
	} else
		return block->phys_pos;
}

/* Returns the number of contiguous bytes following @blockoff. */
static inline uoff_t
blockoff_len(const blockoff_t *blockoff)
{
	return blockoff->block->t.size - blockoff->off;
}

static size_t
blockoff_len_max(const blockoff_t *blockoff, size_t maxlen)
{
	uoff_t ret = blockoff_len(blockoff);
	return ret < maxlen ? (size_t)ret : maxlen;
}

/* Move blockoff's from @old to @new, adding @off to their block
 * offsets to keep them at the same position. */
static void
update_blockoffs(const struct file_block *old, struct file_block *new,
		 off_t off)
{
	blockoff_t *blockoff;

	BDEBUG("Updating blockoffs from <%p> to <%p>%c%llx\n",
	       old, new, off >= 0 ? '+' : '-', off >= 0 ? off : -off);

	list_for_each_entry(blockoff, &old->refs, list) {
		blockoff->block = new;
		blockoff->off += off;
	}
}

/* Move blockoff's in the range (@start;@end> from @old to @new,
 * adding @off to their block offset, plus moving the reference list. */
static void
move_blockoffs(const struct file_block *old, struct file_block *new,
	       uoff_t start, uoff_t end, off_t off)
{
	blockoff_t *blockoff, *nextoff;

	BDEBUG("Moving blockoffs from <%p>:%llx:%llx to <%p>%c%llx\n",
	       old, start, end, new,
	       off >= 0 ? '+' : '-', off >= 0 ? off : -off);

	list_for_each_entry_safe(blockoff, nextoff, &old->refs, list)
		if (blockoff->off >= start && blockoff->off < end) {
			blockoff->block = new;
			blockoff->off += off;
			list_move(&blockoff->list, &new->refs);
		}
}

/* Destroy blockoffs referencing @block from @start to @end */
static void
nuke_blockoffs(const struct file_block *block, uoff_t start, uoff_t end)
{
	blockoff_t *blockoff, *nextoff;

	BDEBUG("Nuking blockoffs from <%p>:%llx:%llx\n",
	       block, start, end);
	list_for_each_entry_safe(blockoff, nextoff, &block->refs, list)
		if (blockoff->off >= start && blockoff->off < end) {
			blockoff->block = NULL;
			list_del_init(&blockoff->list);
		}
}

/* Update the positions of blockoffs at and after @start for all
 * blocks starting at @block */
static void
slide_blockoffs(struct file *file, const struct file_block *block,
		uoff_t start, off_t off)
{
	blockoff_t *blockoff;

	BDEBUG("Sliding blockoffs >= %llx by %c%llx, starting at <%p>\n",
	       start, off >= 0 ? '+' : '-', off >= 0 ? off : -off, block);
	while (is_a_block(&file->blocks, block)) {
		list_for_each_entry(blockoff, &block->refs, list)
			if (blockoff->pos >= start)
				blockoff->pos += off;
		block = next_block(block);
	}
}

static inline size_t
round_up_alloc(size_t alloc)
{
	return alloc + FILE_ALLOC_INC - alloc % FILE_ALLOC_INC;
}

static struct file_block *
file_new_block(struct file *file, int flags)
{
	size_t extra = flags & BLOCK_INSERTED ? sizeof(struct file_data) : 0;
	struct file_block *new = calloc(1, sizeof(struct file_block) + extra);
	if (!new)
		return NULL;

	new->flags = flags;
	init_block_link(new);
	INIT_LIST_HEAD(&new->refs);
	if (extra)
		new->dataobj = (void*)new + sizeof(struct file_block);
	if (flags & BLOCK_EXCACHE)
		INIT_LIST_HEAD(&new->lru);
	else
		list_add_tail(&new->lru, &file->lru);

	return new;
}

static struct file_block *
new_virt_block(struct file *file, uoff_t pos, uoff_t size)
{
	struct file_block *new;

	new = file_new_block(file, BLOCK_EXCACHE | BLOCK_VIRTUAL);
	if (!new)
		return NULL;
	new->t.size = size;
	new->phys_pos = pos;
	BDEBUG("Spawned new virtual block [%llx]\n", size);
	return new;
}

static void
file_free_block(struct file *file, struct file_block *block)
{
	if (block->dataobj)
		file_cache_put(file->cache, block->dataobj);
	list_del(&block->lru);

	free(block);
}

static bool
kill_block_if_empty(struct file *file, struct file_block *block)
{
	if (block->t.size == 0) {
		/* No recalculation needed, zero size. */
		unchain_block(&file->blocks, block);
		assert(list_empty(&block->refs));
		file_free_block(file, block);
		return true;
	}
	return false;
}

/* This may kill the previous block as well, if it can be merged
 * with the next one. It will never kill anything which _follows_. */
static void
file_kill_block(struct file *file, struct file_block *block)
{
	uoff_t phys_pos = block->phys_pos;
	struct file_block *prev = prev_block(block);
	struct file_block *next = next_block(block);
	struct file_block *merger;
	bool killprev = false;

	/* We should never kill a dirty block! */
	assert(!block_is_dirty(block));
	/* We shouldn't get with an empty block here (that might
	 * need special considerations with virtualization). */
	assert(block->t.size > 0);

	if (is_a_block(&file->blocks, next) &&
	    block_is_inner_virtual(next) &&
	    phys_pos + block->t.size == next->phys_pos) {
		if (is_a_block(&file->blocks, prev) &&
		    block_is_inner_virtual(prev) &&
		    prev->phys_pos + prev->t.size == phys_pos)
			killprev = true;
		merger = next;
		merger->phys_pos -= block->t.size;
		update_blockoffs(merger, merger, block->t.size);
		update_blockoffs(block, merger, 0);
	} else if (is_a_block(&file->blocks, prev) &&
		   block_is_inner_virtual(prev) &&
		   prev->phys_pos + prev->t.size == phys_pos) {
		merger = prev;
		update_blockoffs(block, merger, merger->t.size);
	} else if (!block_is_virtual(block)) {
		/* Convert physical to virtual */
		assert(block->dataobj);
		assert(block->phys_pos == block->dataobj->pos + block->dataoff);
		file_cache_put(file->cache, block->dataobj);
		block->dataobj = NULL;

		list_del_init(&block->lru); /* unlink the block from LRU */
		block_set_excache(block); /* say it's unlinked */
		block_set_virtual(block);
		return;
	} else
		/* Already virtual and cannot merge */
	 	return;

	list_splice(&block->refs, &merger->refs);

	/* Messing with block sizes and unchaining is a bit tricky
	 * since unchain_block() can splay(). So we really need
	 * to recalc_node_recursive() right after we update the size.
	 * If this place turns out to be a hot-spot, we can optimize
	 * the tree operations here. */
	merger->t.size += block->t.size;
	recalc_node_recursive(&file->blocks, merger);

	/* Destroy the block */
	recalc_unchain_block(&file->blocks, block);
	file_free_block(file, block);

	if (killprev)
		file_kill_block(file, prev);
}

static struct file_block *
split_block(struct file *file, struct file_block *block, size_t splitpoint,
	    bool makecopy)
{
	struct file_block *next;

	next = file_new_block(file, block->flags);
	if (!next)
		return NULL;

	if (makecopy) {
		size_t remain = block->t.size - splitpoint;
		assert(block_is_inserted(block));
		if (file_data_init(next->dataobj,
				   block->phys_pos, remain)) {
			free(next);
			return NULL;
		}
		memcpy(next->dataobj->data, block_data(block) + splitpoint,
		       remain);
		next->dataoff = 0;
	} else if ( (next->dataobj = block->dataobj) ) {
		file_cache_get(next->dataobj);
		next->dataoff = block->dataoff + splitpoint;
	} else
		assert(block_is_virtual(block));

	next->t.size = block->t.size - splitpoint;
	next->phys_pos = block->phys_pos;
	if (!block_is_inserted(block))
		next->phys_pos += splitpoint;

	block->t.size = splitpoint;
	recalc_node_recursive(&file->blocks, block);
	recalc_chain_block_after(&file->blocks, block, next);

	move_blockoffs(block, next, splitpoint, splitpoint + next->t.size,
		       -(off_t)splitpoint);

	return next;
}

static char *
swp_filename(const char *filename)
{
	size_t fnlen = strlen(filename);
	char *swp;
	char *file;

	if (!(swp = malloc(fnlen + 9)) )
		return NULL;
	strcpy(swp, filename);

	file = strrchr(swp, '/');
	file = file ? file + 1 : swp;
	memmove(file + 1, file, strlen(file) + 1);
	*file = '.';
	strcat(file, ".hedswp");
	return swp;
}

static int
check_swp(const char *filename)
{
	char *swp = swp_filename(filename);

	if (!swp)
		return -1;

	if (access(swp, F_OK)) {
		free(swp);
		return 0;
	}

	fprintf(stderr,
		"Error: Swap file %s for file %s exists\n"
		"This means that hed did not quit properly the last time\n"
		"you edited this file. You can use the swap file to restore\n"
		"some of your unsaved work. Run hed with --restore-swp to\n"
		"do that (until you save your file, the swap file will\n"
		"stay around). Run hed with --remove-swp to get rid of\n"
		"the file. (You can also use both options simultanously.)\n",
		swp, filename);
	errno = 0;
	free(swp);
	return 1;
}

void
file_rmswp(const char *name)
{
	char *swpfile = swp_filename(name);
	if (swpfile) {
		remove(swpfile);
		free(swpfile);
	}
}

int
file_update_size(struct file *file)
{
	uoff_t oldsize = file->phys_size;

	if(fstat(file->fd, &file->s) < 0)
		return -1;

	if (S_ISBLK(file->s.st_mode)) {
		if (ioctl(file->fd, BLKGETSIZE64, &file->phys_size)) {
			unsigned long size32;
			if (ioctl(file->fd, BLKGETSIZE, &size32))
				return -1;
			file->phys_size = (uoff_t)size32 * 512;
		}
	} else if (S_ISREG(file->s.st_mode)) {
		file->phys_size = file->s.st_size;
	} else {
		errno = EINVAL;
		return -1;
	}

	file->size += file->phys_size - oldsize;
	return 0;
}

#ifdef CONFIG_MMAP
# define EMBED	false
#else
# define EMBED	true
#endif

static struct file *
file_basic_init(const char *name)
{
	int fd;
	struct file *file;

	file = calloc(1, sizeof(struct file) +
		      file_cache_size(CACHE_LENGTH, FILE_BLOCK_SIZE, EMBED));
	if (!file)
		return NULL;

	file->fd = fd = open(name, O_RDONLY);
	if (fd < 0) {
		if (errno != ENOENT) {
			free(file);
			return NULL;
		}
		fprintf(stderr, "Warning: File %s does not exist\n", name);
		memset(&file->s, 0, sizeof(struct stat));

	} else if (file_update_size(file)) {
		int errsv = errno;
		close(fd);
		free(file);
		errno = errsv;
		return NULL;
	}

	file->name = name;
	file->fd = fd;
	init_block_list(&file->blocks);
	file->cache = (void*)file + sizeof(struct file);
	file_cache_init(file->cache, CACHE_LENGTH, FILE_BLOCK_SIZE, EMBED);
	INIT_LIST_HEAD(&file->lru);

	return file;
}


struct file *
file_init(const char *name)
{
	struct file *file;
	uoff_t phys_size;
	struct file_block *block = NULL;
	struct file_block *vblock;

	assert(name);

#ifdef CONFIG_MMAP
	sys_page_size = sysconf(_SC_PAGESIZE);
	/* FILE_BLOCK_* macros only work with page sizes which
	 * are a power of two. Abort if this is not the case. */
	assert(sys_page_size == FILE_BLOCK_ROUND(sys_page_size));
#endif

	if (check_swp(name))
		return NULL;

	if (! (file = file_basic_init(name)) )
		return NULL;

	phys_size = file_size(file);
	if (phys_size) {
		block = new_virt_block(file, 0, phys_size);
		if (!block)
			goto error_out;
		chain_block(&file->blocks, block);
	}

	vblock = new_virt_block(file, phys_size, OFF_MAX - phys_size + 1);
	if (!vblock)
		goto error_out;
	block_set_eof(vblock);
	recalc_chain_block(&file->blocks, vblock);

	return file;

 error_out:
	if (block)
		file_free_block(file, block);
	file_done(file);
	return NULL;
}

static void
file_basic_done(struct file *file)
{
	struct file_block *block, *next;

	assert(file);

	foreachsafe_in_tree (block, next, &file->blocks, struct file_block, t)
		file_free_block(file, block);

	/* Do not check for errors:
	 *  1. This FD is read-only => no data loss possbile
	 *  2. We're about to exit anyway => no resource leak
	 */
	if (file->fd >= 0)
		close(file->fd);
	free(file);
}

void
file_done(struct file *file)
{
	file_basic_done(file);
}

static struct file_data *
alloc_cache(struct file *file, off_t pos)
{
	struct file_data *ret;

	while (! (ret = file_cache_alloc(file->cache, pos))) {
		assert(!list_empty(&file->lru));

		/* Kill the least recently used block */
		file_kill_block(file, list_entry(file->lru.next,
						 struct file_block, lru));
	}

	return ret;
}

#ifdef CONFIG_MMAP

static inline void *
file_alloc_data(void)
{
	void *ret = mmap(NULL, FILE_BLOCK_SIZE,
			 PROT_READ | PROT_WRITE,
			 MAP_PRIVATE | MAP_ANONYMOUS,
			 0, 0);
	return ret != MAP_FAILED ? ret : NULL;
}

static inline void
file_dealloc_data(void *data)
{
	if (data)
		munmap(data, FILE_BLOCK_SIZE);
}

#else  /* CONFIG_MMAP */

#define file_dealloc_data(data)		do{} while(0)

#endif	/* CONFIG_MMAP */

#ifdef CONFIG_READAHEAD

#ifdef CONFIG_MMAP

static inline void
unmap_init(void *data, void **pstart, void **pend)
{
	if (data) {
		*pstart = data;
		*pend = data + FILE_BLOCK_SIZE;
	} else
		*pstart = *pend = MAP_FAILED;
}

static inline void
unmap_finish(void *start, void *end)
{
	if (start != end)
		munmap(start, end - start);
}

static inline void
remap_caches(struct file *file, struct file_data **preload, int n,
	     void *const *pdata, void **pstart, void **pend)
{
	void *data = *pdata;
	int i;

	for (i = 0; i < n; ++i) {
		void *old_data = preload[i]->data;
		if (old_data) {
			if (old_data == *pend)
				*pend = old_data + FILE_BLOCK_SIZE;
			else if (old_data + FILE_BLOCK_SIZE == *pstart)
				*pstart = old_data;
			else {
				if (*pstart != *pend)
					munmap(*pstart, *pend - *pstart);
				*pstart = old_data;
				*pend = old_data + FILE_BLOCK_SIZE;
			}
		}
		preload[i]->data = data;
		data += FILE_BLOCK_SIZE;
	}
}

#else  /* CONFIG_MMAP */

#define unmap_init(data,pstart,pend)	do{} while(0)
#define unmap_finish(start,end)		do{} while(0)

static inline void
remap_caches(struct file *file, struct file_data **preload, int n,
	     void **pdata, void **pstart, void **pend)
{
	void *data;
	int i;

	file_cache_compact(file->cache, preload, n);

	*pdata = data = preload[0]->data;
	for (i = 0; i < n; ++i, data += FILE_BLOCK_SIZE)
		preload[i]->data = data;
}

#endif	/* CONFIG_MMAP */

/* This routine is used only for readahead, so it is reasonable to
 * optimize it for the case where current cached blocks will not be
 * reused soon. Freeing cache objects beforehand saves one search
 * through used blocks per alloc.
 */
static void
alloc_caches(struct file *file, off_t pos, struct file_data **caches, int n)
{
	int i = 0;

	assert(n <= CACHE_LENGTH);
	while (i < n) {
		struct file_block *block;

		if(list_empty(&file->lru))
			break;

		block = list_entry(file->lru.next, struct file_block, lru);
		if (block->dataobj->u2.used.refcount <= 1)
			++i;
		file_kill_block(file, block);
 	}

	for (i = 0; i < n; ++i) {
		caches[i] = file_cache_alloc(file->cache, pos);
		assert(caches[i]);
		pos += FILE_BLOCK_SIZE;
	}
}

static inline void
free_caches(struct file *file, struct file_data **preload, int n)
{
	int i;

	for (i = 0; i < n; ++i)
		file_cache_put(file->cache, preload[i]);
}

static void *
alloc_readahead(struct file *file, uoff_t pos, int n,
		struct file_block *block, void *data)
{
	struct file_data *contig[FILE_READAHEAD];
	struct file_data *dataobj = block->dataobj;
	struct file_data **preload;
	void *map_start, *map_end;

	unmap_init(dataobj->data, &map_start, &map_end);

	if (--n) {
		if (file->readahead != FILE_RA_BACKWARD) {
			pos += FILE_BLOCK_SIZE;
			preload = contig;
			*preload++ = dataobj;
		} else {
			contig[n] = dataobj;
			preload = contig;
		}

		list_del(&block->lru);
		alloc_caches(file, pos, preload, n);
		list_add_tail(&block->lru, &file->lru);

		remap_caches(file, contig, n+1, &data, &map_start, &map_end);
		free_caches(file, preload, n);
	} else
		dataobj->data = data;

	unmap_finish(map_start, map_end);

	return data;
}

#define READAHEAD_SIZE	(FILE_READAHEAD * FILE_BLOCK_SIZE)

static int
compute_readahead(struct file *file, uoff_t *offset)
{
	if (file->readahead == FILE_RA_FORWARD)
		return file->phys_size - *offset < READAHEAD_SIZE
			? (file->phys_size - *offset - 1) / FILE_BLOCK_SIZE + 1
			: FILE_READAHEAD;
	else if(file->readahead == FILE_RA_BACKWARD) {
		int n = *offset < READAHEAD_SIZE - FILE_BLOCK_SIZE
			? *offset / FILE_BLOCK_SIZE
			: FILE_READAHEAD - 1;
		*offset -= n * FILE_BLOCK_SIZE;
		return n + 1;
	} else
		return 1;
}

#else  /* CONFIG_READAHEAD */

#define compute_readahead(file,offset)	1

static inline void *
alloc_readahead(struct file *file, uoff_t pos, int n,
		struct file_block *block, void *data)
{
	file_dealloc_data(block->dataobj->data);
	return block->dataobj->data = data;
}

#endif	/* CONFIG_READAHEAD */

static struct file_block *
alloc_block(struct file *file, off_t pos, struct file_data *dataobj)
{
	struct file_block *new;

	if (! (new = file_new_block(file, 0)) )
		return NULL;
	new->dataobj = dataobj;

	return new;
}

static int
file_load_data(struct file *file, struct file_block *block)
{
	struct file_data *dataobj = block->dataobj;
	uoff_t offset = dataobj->pos;
	void *data = dataobj->data;
	ssize_t rsize, total, segsize;
	int n;

	n = compute_readahead(file, &offset);
	data = alloc_readahead(file, offset, n, block, data);

	segsize = n * FILE_BLOCK_SIZE;
	for (total = 0; total < segsize; total += rsize) {
		rsize = pread(file->fd, data + total,
			      segsize - total, offset + total);
		if (rsize < 0)
			return -1;
		if (!rsize)
			break;
	}

	BDEBUG("Loaded data at phys %llx up to %llx\n",
	       offset, offset + segsize);
	return 0;
}

#ifdef CONFIG_MMAP

static int
file_load_data_mmap(struct file *file, struct file_block *block)
{
	struct file_data *dataobj = block->dataobj;
	void *data = dataobj->data;
	uoff_t offset = dataobj->pos;
	int n;

	n = compute_readahead(file, &offset);
	data = mmap(NULL, n * FILE_BLOCK_SIZE,
		    PROT_READ | PROT_WRITE,
		    MAP_PRIVATE | (file->fd < 0 ? MAP_ANONYMOUS : 0),
		    file->fd, offset);

	if (data == MAP_FAILED) {
		BDEBUG("mmap failed at %llx: fail over to traditional read\n",
			offset);

		file_dealloc_data(dataobj->data);
		if (! (dataobj->data = file_alloc_data()) )
			return -1;

		return file_load_data(file, block);
	}

	alloc_readahead(file, offset, n, block, data);

	BDEBUG("Loaded data at phys %llx up to %llx\n",
	       offset, offset + n * FILE_BLOCK_SIZE);
	return 0;
}
# define file_load_data	file_load_data_mmap

#endif

static struct file_block *
get_loaded_block(struct file *file, uoff_t phys_offset, size_t size)
{
	struct file_data *dataobj;
	struct file_block *new;
	size_t dataoff = FILE_BLOCK_OFF(phys_offset);

	if (file->fd < 0)
		return NULL;

	phys_offset -= dataoff;
	dataobj = alloc_cache(file, phys_offset);
	new = alloc_block(file, phys_offset, dataobj);
	if (!new) {
		file_cache_put(file->cache, dataobj);
		return NULL;
	}

	if (file_data_is_reused(dataobj))
		BDEBUG("Reusing loaded data\n");
	else if (file_load_data(file, new)) {
		file_free_block(file, new);
		return NULL;
	}

	new->dataoff = dataoff;
	if (size > FILE_BLOCK_SIZE - dataoff)
		new->t.size = FILE_BLOCK_SIZE - dataoff;
	else
		new->t.size = size;
	new->phys_pos = phys_offset + dataoff;

	BDEBUG("Loaded block %llx:(%x,%llx)\n",
	       phys_offset, size, new->t.size);
	return new;
}

/* Enlarge a physical block at beginning and shorten the preceding
 * virtual block by @len bytes. The enlargement must be chosen so
 * that the physical block can hold all bytes. */
static void
enlarge_phys_begin(struct file *file, struct file_block *block,
		   struct file_block *prev, size_t len)
{
	assert(!block_is_virtual(block));
	assert(block_is_virtual(prev));
	assert (len <= block->dataoff);

	/* Shif blockoffs in the new physical block */
	update_blockoffs(block, block, len);

	/* Move blockoffs away from the to-be-chopped end */
	move_blockoffs(prev, block, prev->t.size - len, prev->t.size,
		       -(prev->t.size - len));

	/* Enlarge the physical block */
	block->dataoff -= len;
	block->phys_pos -= len;
	block->t.size += len;
	recalc_node_recursive(&file->blocks, block);

	/* Shorten the preceding virtual block */
	prev->t.size -= len;
	recalc_node_recursive(&file->blocks, prev);
}

/* Enlarge a physical block at end and shorten the following virtual
 * block by at most @len bytes.
 * Note: The physical block may grow by less than @len bytes if the
 * data object cannot accomodate the full new length. */
static void
enlarge_phys_end(struct file *file, struct file_block *block,
		 struct file_block *next, size_t len)
{
	assert(!block_is_virtual(block));
	assert(block_is_virtual(next));

	/* Get less bytes than requested, if not enough room */
	if (len > block->dataobj->size - block->dataoff - block->t.size)
		len = block->dataobj->size - block->dataoff - block->t.size;

	/* Move blockoffs away from the to-be-chopped beginning */
	move_blockoffs(next, block, 0, len, block->t.size);

	/* Enlarge the physical block */
	block->t.size += len;
	recalc_node_recursive(&file->blocks, block);

	/* Shorten the following virtual block */
	next->t.size -= len;
	next->phys_pos += len;
	recalc_node_recursive(&file->blocks, next);
}

/* Create a new dirty physical block in the middle of a virtual @block.
 * Note: The virtual block must cover the full length of the new block.
 */
static int
create_physical(struct file *file, const blockoff_t *blockoff, size_t part,
		size_t len, bool makedirty)
{
	struct file_block *block = blockoff->block;
	uoff_t offset = blockoff->off - part;
	struct file_block *physblock;
	uoff_t physoff;

	assert(block_is_virtual(block));
	assert(len <= block->t.size - offset);

	/* Get the physical offset of the new block */
	physoff = block->phys_pos;
	physoff += offset;

	/* Initialize a new block */
	if (makedirty) {
		physblock = file_new_block(file, BLOCK_EXCACHE | BLOCK_DIRTY);
		if (!physblock)
			goto out_err;

		physblock->dataobj =
			file_data_new(physoff, round_up_alloc(len));
		if (!physblock->dataobj)
			goto out_err_free;
		physblock->phys_pos = physoff;
	} else {
		physblock = get_loaded_block(file, physoff, len);
		if (!physblock)
			goto out_err;
		len = physblock->t.size;
		block = blockoff->block;
		offset = blockoff->off - part;
	}

	/* Re-create the tail block */
	if (block->t.size - offset > len) {
		struct file_block *tail;

		tail = new_virt_block(file, block->phys_pos + offset + len,
				      block->t.size - offset - len);
		if (!tail)
			goto out_err_free;

		recalc_chain_block_after(&file->blocks, block, tail);

		/* Move offsets to the tail */
		move_blockoffs(block, tail, offset + len, block->t.size,
			       -(offset + len));
	}

	/* Move pointers to the physical block */
	move_blockoffs(block, physblock, offset, offset + len, -offset);

	/* Shorten the leading virtual block */
	block->t.size = offset;
	recalc_node_recursive(&file->blocks, block);

	/* Insert the new physical block */
	physblock->t.size = len;
	recalc_chain_block_after(&file->blocks, block, physblock);

	return 0;

 out_err_free:
	file_free_block(file, physblock);
 out_err:
	return -1;
}

/* This punches a non-virtual hole of at most @len bytes inside
 * a virtual block.
 * If @makedirty is true, the hole is unitialized (and marked dirty),
 * otherwise its content is loaded from disk (and marked clean). */
static int
devirtualize(struct file *file, const blockoff_t *blockoff, size_t len,
	     bool makedirty)
{
	struct file_block *block = blockoff->block;
	uoff_t block_offset = blockoff->off;
	struct file_block *prev = prev_block(block);
	struct file_block *next = next_block(block);
	size_t part = 0;
	long wantflags;

	if (!makedirty) {
		part = FILE_BLOCK_OFF(block->phys_pos + block_offset);
		if (part > block_offset)
			part = block_offset;
		block_offset -= part;
		len += part;
	}

	if (len > block->t.size - block_offset)
		len = block->t.size - block_offset;

	BDEBUG("punch a hole at %llx:%lx into %llx:%llx\n",
	       block_offset, len,
	       block_offset(&file->blocks, block), block->t.size);

	assert(block_is_virtual(block));
	wantflags = makedirty ? BLOCK_DIRTY : 0;

	if ((!makedirty || !block_offset) &&
	    is_a_block(&file->blocks, prev) &&
	    (prev->flags & BLOCK_STATEMASK) == wantflags &&
	    prev->phys_pos + prev->t.size == block->phys_pos &&
	    prev->t.size + block_offset < prev->dataobj->size - prev->dataoff) {
		/* We can chop the virtual segment before our point and
		 * accomodate it in the previous block. */
		BDEBUG("Appending to previous block\n");
		enlarge_phys_end(file, prev, block, len + block_offset);
	} else if (block_offset >= block->t.size - len &&
		   is_a_block(&file->blocks, next) &&
		   (next->flags & BLOCK_STATEMASK) == wantflags &&
		   block->phys_pos + block->t.size == next->phys_pos &&
		   next->dataoff >= len) {
		/* We can chop the virtual segment after our point and
		 * accomodate it in the following block. */
		BDEBUG("Prepending to next block\n");
		enlarge_phys_begin(file, next, block, len);
	} else {
		/* We will need a new block */
		if (create_physical(file, blockoff, part, len, makedirty))
			return -1;
	}

	/* Kill the virtual block if possible */
	kill_block_if_empty(file, block);

	dump_blocks(file);

	return 0;
}

static size_t
copy_in(struct file *file, void *buf, size_t count, blockoff_t *pos)
{
	pos->pos += count;

	assert(is_a_block(&file->blocks, pos->block));

	do {
		size_t cpylen = blockoff_len_max(pos, count);

		if (block_is_virtual(pos->block))
			memset(buf, 0, cpylen);
		else
			memcpy(buf, block_data(pos->block) + pos->off, cpylen);

		buf += cpylen;
		pos->off += cpylen;
		count -= cpylen;
	} while(count && !file_next_block(file, pos));

	pos->pos -= count;
	return count;
}

size_t
file_cpin(struct file *file, void *buf, size_t count, blockoff_t *pos)
{
	blockoff_t mypos;
	size_t ret;

	file_dup_blockoff(pos, &mypos);
	ret = copy_in(file, buf, count, &mypos);
	file_put_blockoff(&mypos);
	return ret;
}

void *
file_fetch_block(struct file *file, uoff_t offset, size_t *size)
{
	unsigned char *buf;
	blockoff_t pos_blk;
	size_t real_size;

	real_size = *size;
	if (real_size > file->size - offset)
		real_size = file->size - offset;

	_file_get_blockoff(file, offset, &pos_blk);

	if (file_read_begin(file, &pos_blk, real_size) < 0)
		goto out_err;

	buf = calloc(1, real_size);
	if (!buf)
		goto out_err;

	if (copy_in(file, buf, real_size, &pos_blk))
		goto out_err_free;

	file_read_end(file);
	file_put_blockoff(&pos_blk);

	*size = real_size;
	return buf;

 out_err_free:
	free(buf);
 out_err:
	file_put_blockoff(&pos_blk);
	*size = 0;
	return NULL;
}

/* Ensure that blockoff points to an up-to-date non-virtual block.
 * Load the data from disk if necessary, return 0 on success. */
static int
ensure_uptodate(struct file *file, const blockoff_t *blockoff)
{
	struct file_block *block = blockoff->block;
	if (!block_is_virtual(block) || block->phys_pos >= file->phys_size)
		return 0;

	return devirtualize(file, blockoff, FILE_BLOCK_SIZE, false);
}

int
file_read_begin(struct file *file, const blockoff_t *blockoff, size_t length)
{
#ifdef CONFIG_MMAP
	fixup_begin();
#endif
	return ensure_uptodate(file, blockoff);
}

/* Adjust blockoff after off gets outside its block */
static void
fixup_blockoff_slow(blockoff_t *blockoff)
{
	struct file_block *block = blockoff->block;
	uoff_t off = blockoff->off;

	do {
		if ((off_t)off < 0) {
			block = prev_block(block);
			off += block->t.size;
		} else {
			off -= block->t.size;
			block = next_block(block);
		}
	} while (off >= block->t.size);

	blockoff->block = block;
	blockoff->off = off;
	list_move(&blockoff->list, &block->refs);
}

/* Adjust blockoff if off gets outside its block.
 * This is separate from fixup_blockoff_slow, because it is supposed
 * to be small enough to be inlined (which is a win, because most of
 * the time no fixup has to be done, so the fast inlined path is used).
 */
static inline void
fixup_blockoff(blockoff_t *blockoff)
{
	if (blockoff->off >= blockoff->block->t.size)
		fixup_blockoff_slow(blockoff);
}

off_t
file_move_relative(blockoff_t *blockoff, off_t num)
{
	off_t newpos = blockoff->pos + num;
	if (newpos < 0) {
		newpos = num < 0 ? 0 : OFF_MAX;
		num = newpos - blockoff->pos;
	}
	blockoff->pos = newpos;
	blockoff->off += num;
	fixup_blockoff(blockoff);
	return num;
}

/* Relative move with no checking (and only by a small amount) */
static inline void
file_move_rel_fast(blockoff_t *blockoff, ssize_t num)
{
	blockoff->off += num;
	blockoff->pos += num;
	fixup_blockoff(blockoff);
}

/* Move the block pointer to the next block */
static int
blockoff_next_block(struct file *file, blockoff_t *blockoff)
{
	struct file_block *block = blockoff->block;

	do {
		block = next_block(block);
		if (!is_a_block(&file->blocks, block))
			return -1;
	} while (!block->t.size);

	blockoff->block = block;
	blockoff->off = 0;
	list_move(&blockoff->list, &block->refs);
	return 0;
}

/* This is an optimized way of doing:
 *
 *   file_move_relative(blockoff, blockoff->block->t.size);
 *
 * for the case when blockoff->off == 0.
 */
static int
move_to_next(struct file *file, blockoff_t *blockoff)
{
	blockoff->pos += blockoff->block->t.size;
	return blockoff_next_block(file, blockoff);
}

int
file_next_block(struct file *file, blockoff_t *blockoff)
{
	if (blockoff_next_block(file, blockoff))
		return -1;

	return ensure_uptodate(file, blockoff);
}

static int
make_block_dirty(struct file *file, struct file_block *block)
{
	if (!block_is_excache(block)) {
		struct file_data *detached;

		detached = file_cache_detach(file->cache, block->dataobj);
		if (!detached)
			return -1;

		block->dataobj = detached;
		list_del_init(&block->lru);
		block_set_excache(block);
	}

	block_set_dirty(block);
	return 0;
}

/* If a blockoff is virtual, convert it to a suitable non-virtual block. */
static inline int
prepare_modify(struct file *file, blockoff_t *blockoff, size_t len)
{
	if (!block_is_virtual(blockoff->block))
		return 0;
	return devirtualize(file, blockoff, len, true);
}

int
file_set_byte(struct file *file, blockoff_t *blockoff, unsigned char byte)
{
	uoff_t offset = blockoff->pos;

	if (prepare_modify(file, blockoff, 1))
		return -1;

	if (make_block_dirty(file, blockoff->block))
		return -1;
	file->modified = true;

	if (offset >= file->size)
		file->size = offset + 1;

	block_data(blockoff->block)[blockoff->off] = byte;
	block_set_bytedirty(blockoff);
	return 0;
}

size_t
file_set_block(struct file *file, blockoff_t *blockoff, unsigned char *buf, size_t len)
{
	blockoff_t pos;

	file_dup_blockoff(blockoff, &pos);

	while (len) {
		size_t span;

		if (prepare_modify(file, &pos, len))
			break;

		if (make_block_dirty(file, pos.block))
			break;
		file->modified = true;

		span = blockoff_len_max(&pos, len);
		memcpy(block_data(pos.block) + pos.off, buf, span);
		buf += span;
		len -= span;
		pos.pos += span;

		/* FIXME: this can be improved */
		while (span--) {
			block_set_bytedirty(&pos);
			pos.off++;
		}

		if (file_next_block(file, &pos))
			break;
	}
	if (pos.pos > file->size)
		file->size = pos.pos;
	file_put_blockoff(&pos);

	return len;
}

uoff_t
file_set_bytes(struct file *file, blockoff_t *blockoff, unsigned char byte, uoff_t rep)
{
	blockoff_t pos;

	file_dup_blockoff(blockoff, &pos);

	while (rep) {
		size_t span;

		if (prepare_modify(file, &pos, rep))
			break;

		if (make_block_dirty(file, pos.block))
			break;
		file->modified = true;

		span = blockoff_len_max(&pos, rep);
		memset(block_data(pos.block) + pos.off, byte, span);
		rep -= span;
		pos.pos += span;

		/* FIXME: this can be improved */
		while (span--) {
			block_set_bytedirty(&pos);
			pos.off++;
		}

		if (file_next_block(file, &pos))
			break;
	}
	if (pos.pos > file->size)
		file->size = pos.pos;
	file_put_blockoff(&pos);

	return rep;
}

static int
file_erase_continuous(struct file *file, blockoff_t *blockoff, size_t len)
{
	struct file_block *block = blockoff->block;
	uoff_t block_offset = blockoff->off;

	/* Move to the new position, so blockoff does not get destroyed */
	file_move_relative(blockoff, len);

	nuke_blockoffs(block, block_offset, block_offset + len);

	if (!block_is_virtual(block)) {
		if (!block_offset && block_is_inserted(block)) {
			update_blockoffs(block, block, -(uoff_t)len);
			block->dataoff += len;
			if (!block_is_inserted(block))
				block->phys_pos += len;
		} else if (block_offset + len < block->t.size) {
			if (!split_block(file, block, block_offset + len,
					 false))
				return -1;
		}
	} else
		move_blockoffs(block, block,
			       block_offset, block->t.size, -(uoff_t)len);
	block->t.size -= len;
	recalc_node_recursive(&file->blocks, block);

	kill_block_if_empty(file, block);
	return 0;
}

size_t
file_erase_block(struct file *file, blockoff_t *blockoff, uoff_t len)
{
	uoff_t offset;
	uoff_t todo;
	uoff_t coversize;

	offset = blockoff->pos;
	if (offset > file->size)
		return 0;
	else if (len > file->size - offset)
		len = file->size - offset;

	todo = len;
	while (todo) {
		size_t span = blockoff_len_max(blockoff, todo);

		if (file_erase_continuous(file, blockoff, span))
			break;

		todo -= span;
	}
	len -= todo;

	file->size -= len;
	file->modified = true;

	coversize = file->blocks.root->cover_size;
	if (coversize <= OFF_MAX) {
		struct file_block *last = last_block(&file->blocks);
		assert(block_is_virtual(last));
		last->t.size += OFF_MAX - coversize + 1;
		recalc_node_recursive(&file->blocks, last);
	}

	slide_blockoffs(file, blockoff->block, blockoff->pos, -len);

	return todo;
}

int
file_insert_begin(struct file *file,
		  blockoff_t *blockoff, blockoff_t *blockoff_ins)
{
	struct file_block *block = blockoff->block;
	struct file_block *newblock;
	uoff_t physoff;

	BDEBUG("Starting insert at %llx\n", blockoff->pos);

	newblock = file_new_block(file, BLOCK_EXCACHE | BLOCK_INSERTED);
	if (!newblock)
		return -1;

	physoff = block->phys_pos + blockoff->off;
	newblock->phys_pos = physoff;
	if (file_data_init(newblock->dataobj, physoff, FILE_BLOCK_SIZE)) {
		file_free_block(file, newblock);
		return -1;
	}

	if (blockoff->off) {
		struct file_block *next;

		next = split_block(file, block, blockoff->off,
				   block_is_inserted(block));
		if (!next) {
			file_free_block(file, newblock);
			return -1;
		}
	} else
		block = prev_block(block);

	if (is_a_block(&file->blocks, block) && block_is_inserted(block)) {
		file_free_block(file, newblock);
		newblock = block;
	} else
		chain_block_after(&file->blocks, block, newblock);

	blockoff_ins->pos = blockoff->pos;
	blockoff_ins->off = newblock->t.size;
	blockoff_ins->block = newblock;
	list_add(&blockoff_ins->list, &newblock->refs);

	dump_blocks(file);
	return 0;
}

/* Shrink an inserted block and try to merge it with next */
static void
compact_insert(struct file *file, struct file_block *block)
{
	struct file_block *next = next_block(block);

	assert(!block_is_virtual(block));
	assert(block_is_inserted(block));

	if (!is_a_block(&file->blocks, next) || !block_is_inserted(next)) {
		/* this is a shrink attempt - errors are not fatal */
		file_data_realloc(block->dataobj, block->t.size);
		return;
	}

	if (file_data_realloc(block->dataobj, block->t.size + next->t.size))
		return;

	memcpy(block_data(block) + block->t.size,
	       block_data(next), next->t.size);
	update_blockoffs(next, block, block->t.size);
	list_splice(&next->refs, &block->refs);
	INIT_LIST_HEAD(&next->refs);

	block->t.size += next->t.size;
	recalc_node_recursive(&file->blocks, block);

	next->t.size = 0;
	recalc_node_recursive(&file->blocks, next);
	kill_block_if_empty(file, next);
}

void
file_insert_end(struct file *file, blockoff_t *blockoff_ins)
{
	struct file_block *block = blockoff_ins->block;

	BDEBUG("End insert at %llx\n", blockoff_ins->pos);

	compact_insert(file, block);

	kill_block_if_empty(file, block);
	blockoff_ins->block = NULL;
	list_del(&blockoff_ins->list);
	dump_blocks(file);
}

size_t
file_insert_block(struct file *file, blockoff_t *blockoff, unsigned char *buf, size_t len)
{
	struct file_block *block = blockoff->block;
	uoff_t offset = blockoff->pos;

	assert(file && offset >= 0);

	if (blockoff->off + len > block->dataobj->size) {
		size_t newsize = round_up_alloc(block->dataobj->size + len);
		BDEBUG("Insert enlarges block from %d to %d\n",
		       block->dataobj->size, newsize);
		if (file_data_realloc(block->dataobj, newsize))
			return len;
	}

	if (make_block_dirty(file, block))
		return len;
	file->modified = true;

	memcpy(block_data(block) + blockoff->off, buf, len);
	block->t.size += len;
	recalc_node_recursive(&file->blocks, block);
	blockoff->off += len;
	blockoff->pos += len;

	if (blockoff->pos > file->size)
		file->size = blockoff->pos;
	else
		file->size += len;

	slide_blockoffs(file, next_block(block), offset, len);

	return 0;
}

int
file_insert_byte(struct file *file, blockoff_t *blockoff, unsigned char byte)
{
	return file_insert_block(file, blockoff, &byte, 1);
}

struct commit_control {
	struct file *file;
	int wfd;		/* file descriptor for writing */
	blockoff_t begoff, endoff;
	off_t shift;
	void *partbuf;		/* allocated 3*FILE_BLOCK_SIZE  */
	void *partial;		/* pointer into partbuf */
};

/* Get the logical<->physical shift value after the specified block.
 * It is essential to get the value _AFTER_ the block, because the
 * shift value is used to decide how the current block will be handled.
 */
static off_t
get_shift(const blockoff_t *blockoff)
{
	struct file_block *block = blockoff->block;
	size_t curshift = block_is_inserted(block) ? block->t.size : 0;
	return curshift +
		blockoff->pos - blockoff->off - block->phys_pos;
}

static void
switch_partial(struct commit_control *cc)
{
	cc->partial += FILE_BLOCK_SIZE;
	if (cc->partial >= cc->partbuf + 3*FILE_BLOCK_SIZE)
		cc->partial = cc->partbuf;
}

static int
commit_block(struct commit_control *cc, void *data, uoff_t off)
{
	size_t len = FILE_BLOCK_SIZE;
	ssize_t written;

	if (len > cc->endoff.pos - off)
		len = cc->endoff.pos - off;
	if (!len)
		return 0;

	BDEBUG(" -> write %lx bytes at %llx\n", (unsigned long)len, off);
	written = pwrite(cc->wfd, data, len, off);
	if (written < len)
		/* TODO: keep data in a new list of dirty blocks */
		return -1;
	return 0;
}

/* Fill the partial block, updating begoff 
 * Returns:
 *  <0	on error
 *   0	on success (no write necessary)
 *  >0	on success (write needed)
 */
static int
fill_partial(struct commit_control *cc)
{
	struct file *file = cc->file;
	uoff_t aligned;
	size_t partoff, partlen;
	int ret = 0;

	aligned = FILE_BLOCK_ROUND(cc->begoff.pos);
	partlen = (cc->endoff.pos - aligned < FILE_BLOCK_SIZE
		   ? cc->endoff.pos - aligned : FILE_BLOCK_SIZE);

	BDEBUG("Fill partial %llx-%llx\n", cc->begoff.pos, aligned + partlen);

	partoff = FILE_BLOCK_OFF(cc->begoff.pos);
	while (partoff < partlen) {
		void *p;
		uoff_t len;

		if (ensure_uptodate(file, &cc->begoff)) {
			file_move_relative(&cc->begoff, partlen - partoff);
			cc->shift = get_shift(&cc->begoff);
			return -1;
		}

		if (block_is_dirty(cc->begoff.block) || cc->shift)
			ret = 1;

		p = block_data(cc->begoff.block);
		if (p)
			p += cc->begoff.off;

		len = blockoff_len(&cc->begoff);
		if (len > partlen - partoff) {
			len = partlen - partoff;
			cc->begoff.pos += len;
			cc->begoff.off += len;
		} else {
			cc->begoff.pos += len;
			if (blockoff_next_block(file, &cc->begoff))
				return -1;
			cc->shift = get_shift(&cc->begoff);
		}

		if (p)
			memcpy(cc->partial + partoff, p, len);
		else
			memset(cc->partial + partoff, 0, len);

		partoff += len;
	}

	return ret;
}

static int
commit_partial(struct commit_control *cc)
{
	uoff_t aligned = FILE_BLOCK_ROUND(cc->begoff.pos);
	int ret;

	if ( (ret = fill_partial(cc)) <= 0)
		return ret;

	if (FILE_BLOCK_OFF(cc->begoff.pos) && cc->begoff.pos != cc->file->size)
		return 0;

	return commit_block(cc, cc->partial, aligned);
}

static int
commit_forwards(struct commit_control *cc)
{
	uoff_t endpos = cc->endoff.pos;
	int ret = 0;

	BDEBUG("Writing forwards %llx-%llx\n",
	       cc->begoff.pos, cc->endoff.pos);

	while (cc->begoff.pos < endpos)
		ret |= commit_partial(cc);

	return ret;
}

static int
commit_backwards(struct commit_control *cc)
{
	void *retpartial = cc->partial;
	uoff_t begpos = cc->begoff.pos;
	uoff_t blkpos;		/* start of current partial block */
	int ret = 0;

	BDEBUG("Writing backwards %llx-%llx\n",
	       cc->begoff.pos, cc->endoff.pos);

	blkpos = FILE_BLOCK_ROUND(cc->endoff.pos);
	if (blkpos <= begpos)
		goto final;

	/* Handle the trailing partial block */
	file_get_blockoff(cc->file, blkpos, &cc->begoff);
	cc->shift = get_shift(&cc->begoff);
	switch_partial(cc);
	ret |= commit_partial(cc);
	retpartial = cc->partial;

	/* Handle the middle part */
	switch_partial(cc);
	while ( (blkpos -= FILE_BLOCK_SIZE) > begpos) {
		file_get_blockoff(cc->file, blkpos, &cc->begoff);
		cc->shift = get_shift(&cc->begoff);
		ret |= commit_partial(cc);
	}
	switch_partial(cc);	/* wrap around */

 final:
	/* Handle the first block (partiall or not) */
	file_get_blockoff(cc->file, begpos, &cc->begoff);
	cc->shift = get_shift(&cc->begoff);
	ret |= commit_partial(cc);

	cc->partial = retpartial;
	file_dup2_blockoff(&cc->endoff, &cc->begoff);
	cc->shift = get_shift(&cc->begoff);

	return ret;
}

static void
undirty_blocks(struct file *file)
{
	struct file_block *block, *next;
	uoff_t pos = 0;

	BDEBUG("Undirtying blocks:\n");
	dump_blocks(file);

	foreachsafe_block (block, next, &file->blocks) {
		if (kill_block_if_empty(file, block))
			continue;

		if (!block_is_virtual(block)) {
			file_cache_put(file->cache, block->dataobj);
			block->dataobj = NULL;
			list_del_init(&block->lru);
			block->flags = BLOCK_EXCACHE | BLOCK_VIRTUAL;
		}

		block->phys_pos = pos;
		pos += block->t.size;
	}

	block = first_block(&file->blocks);
	while (!block_is_eof(block)) {
		next = next_block(block);
		file_kill_block(file, block);
		block = next;
	}

	file_cache_invalidate(file->cache);

	BDEBUG("After undirtying\n");
	dump_blocks(file);
}

static int
commit_init(struct commit_control *cc, struct file *file)
{
	cc->file = file;

	cc->partbuf = malloc(3*FILE_BLOCK_SIZE);
	if (!cc->partbuf)
		goto err;

	cc->wfd = open(file->name,
		       O_RDWR | (file->fd < 0 ? O_CREAT : 0), 0666);
	if (cc->wfd < 0)
		goto err_free;

	if (file->fd < 0 &&
	    (file->fd = open(file->name, O_RDONLY)) < 0)
		goto err_close;

	return 0;

 err_close:
	close(cc->wfd);
 err_free:
	free(cc->partbuf);
 err:
	return -1;
}

int
file_commit(struct file *file)
{
	struct commit_control cc;
	int ret = 0;

	if (commit_init(&cc, file))
		return -1;

	dump_blocks(file);

	cc.partial = cc.partbuf;
	_file_get_blockoff(file, 0,&cc.begoff);
	file_dup_blockoff(&cc.begoff, &cc.endoff);
	cc.shift = -cc.begoff.block->phys_pos;
	while(cc.endoff.pos < file->size) {
		off_t newshift = get_shift(&cc.endoff);

		if (cc.shift <= 0 && newshift > 0) {
			ret |= commit_forwards(&cc);
			file_dup2_blockoff(&cc.endoff, &cc.begoff);
		} else if (cc.shift > 0 && newshift <= 0) {
			ret |= commit_backwards(&cc);
			file_dup2_blockoff(&cc.endoff, &cc.begoff);
		}
		move_to_next(file, &cc.endoff);
	}

	if (cc.begoff.pos < file->size) {
		assert(cc.endoff.pos == file->size);
		if (cc.shift <= 0)
			ret |= commit_forwards(&cc);
		else
			ret |= commit_backwards(&cc);
	}

	file_put_blockoff(&cc.begoff);
	file_put_blockoff(&cc.endoff);

	ftruncate(cc.wfd, file->size);
	file->phys_size = file->size;

	ret |= close(cc.wfd);
	free(cc.partbuf);

	undirty_blocks(file);

	return ret;
}

static void
write_chunk_hdr(uoff_t backlog, uoff_t pbacklog, bool dirty, FILE *swp)
{
	char payload_type = dirty;
	if (!backlog && !pbacklog)
		return;
	fwrite(&payload_type, 1, 1, swp);
	fwrite(&backlog, sizeof(backlog), 1, swp);
	fwrite(&pbacklog, sizeof(pbacklog), 1, swp);
}

void
file_swp(struct file *file)
{
	char *swpfile;
	FILE *swp;
	struct stat s;
	struct file_block *block;
	uoff_t backlog = 0, pbacklog = 0;
	char ver = 0;
	size_t offsize = sizeof(uoff_t);
	bool marks_set['z' - 'a' + 1 + 'Z' - 'A' + 1];
	uoff_t marks['z' - 'a' + 1 + 'Z' - 'A' + 1];
	int mark;

	if (fstat(file->fd, &s))
		return;
	if (! (swpfile = swp_filename(file->name)) )
		return;
	swp = fopen(swpfile, "w");
	free(swpfile);
	if (!swp)
		return;

	fwrite(&ver, 1, 1, swp);
	fwrite(&offsize, sizeof(offsize), 1, swp);
	fwrite(&s, sizeof(s), 1, swp);
	fwrite(&file->size, sizeof(file->size), 1, swp);
	fwrite(&file->modified, sizeof(file->modified), 1, swp);

	/* Save the marks */
	memset(marks_set, 0, sizeof(marks_set));
	memset(marks, 0, sizeof(marks));
	for (mark = 0; mark < sizeof(marks)/sizeof(marks[0]); mark++) {
		if (!is_a_blockoff(&file->marks[mark]))
			continue;
		marks_set[mark] = true;
		marks[mark] = file->marks[mark].pos;
	}
	fwrite(marks_set, sizeof(marks_set), 1, swp);
	fwrite(marks, sizeof(marks), 1, swp);

	/* We will join virtual and cached blocks */
	for (block = first_block(&file->blocks); !block_is_eof(block);
	     block = next_block(block)) {
		if (!block_is_dirty(block)) {
			backlog += block->t.size;
			pbacklog += block_phys_size(file, block);
			if (block->t.size < block_phys_size(file, block)) {
				write_chunk_hdr(backlog, pbacklog, false, swp);
				backlog = pbacklog = 0;
			}
			continue;
		}
		assert(!block_is_virtual(block));
		write_chunk_hdr(backlog, pbacklog, false, swp);
		backlog = pbacklog = 0;
		write_chunk_hdr(block->t.size, block_phys_size(file, block),
				true, swp);
		fwrite(block_data(block), block->t.size, 1, swp);
	}
	write_chunk_hdr(backlog, pbacklog, false, swp);

	fclose(swp);
}

struct file *
file_unswp(const char *name)
{
	char *swpfile;
	struct file *file;
	struct file_block *block;
	FILE *swp;
	struct stat s;
	char payload;
	size_t offsize;
	uoff_t pos;
	bool marks_set['z' - 'a' + 1 + 'Z' - 'A' + 1];
	uoff_t marks['z' - 'a' + 1 + 'Z' - 'A' + 1];
	int mark;

#ifdef CONFIG_MMAP
	sys_page_size = sysconf(_SC_PAGESIZE);
	/* FILE_BLOCK_* macros only work with page sizes which
	 * are a power of two. Abort if this is not the case. */
	assert(sys_page_size == FILE_BLOCK_ROUND(sys_page_size));
#endif

	file = file_basic_init(name);
	if (!file) {
		fprintf(stderr, "Couldn't init file struct\n");
		goto fail_total;
	}

	if (fstat(file->fd, &s)) {
		fprintf(stderr, "stat error\n");
		goto fail_done;
	}
	if (! (swpfile = swp_filename(file->name)) )
		goto fail_done;
	swp = fopen(swpfile, "r");
	free(swpfile);
	if (!swp) {
		fprintf(stderr, "fopen error\n");
		goto fail_done;
	}

	fread(&payload, 1, 1, swp);
	if (payload != 0) {
		fprintf(stderr, "version mismatch\n");
		goto fail_close;
	}

	fread(&offsize, sizeof(offsize), 1, swp);
	if (offsize != sizeof(uoff_t)) {
		fprintf(stderr, "uoff_t size mismatch\n");
		goto fail_close;
	}

	fread(&s, sizeof(s), 1, swp);
	s.st_atime = file->s.st_atime;
	s.st_ctime = file->s.st_ctime;
	if (memcmp(&s, &file->s, sizeof(s))) {
		fprintf(stderr, "stat info mismatch (you modified the file since hed ran on it; refusing to touch it)\n");
		goto fail_close;
	}

	fread(&file->size, sizeof(file->size), 1, swp);
	fread(&file->modified, sizeof(file->modified), 1, swp);
	fread(marks_set, sizeof(marks_set), 1, swp);
	fread(marks, sizeof(marks), 1, swp);

	pos = 0;
	while ((payload = fgetc(swp)) != EOF) {
		uoff_t size, phys_size;
		int flags;

		fread(&size, sizeof(size), 1, swp);
		fread(&phys_size, sizeof(phys_size), 1, swp);
		if (payload == 0) { // virtual
			flags = BLOCK_EXCACHE | BLOCK_VIRTUAL;
		} else if (payload == 1) { // physical
			flags = BLOCK_DIRTY | BLOCK_EXCACHE;
			if (phys_size < block->t.size)
				flags |= BLOCK_INSERTED;
		} else {
			fprintf(stderr, "format error - payload 0x%x\n", payload);
			goto fail_close;
		}

		block = file_new_block(file, flags);
		if (!block)
			goto fail_close;

		block->t.size = size;
		if (payload == 1) {
			if (!block->dataobj) {
				size_t off = FILE_BLOCK_OFF(pos);
				block->dataoff = off;
				block->phys_pos = pos;

				block->dataobj = file_data_new(pos - off,
							       size + off);
				if (!block->dataobj) {
					file_free_block(file, block);
					goto fail_close;
				}
			} else if (file_data_init(block->dataobj, pos, size)) {
				file_free_block(file, block);
				goto fail_close;
			}

			fread(block_data(block), size, 1, swp);
		}
		block->phys_pos = pos;

		recalc_chain_block(&file->blocks, block);

		if (!block_is_inserted(block))
			pos += phys_size;
	}

	block = new_virt_block(file, pos, OFF_MAX - pos + 1);
	if (!block)
		goto fail_close;
	block_set_eof(block);
	recalc_chain_block(&file->blocks, block);

	/* Setup marks */
	for (mark = 0; mark < sizeof(marks)/sizeof(marks[0]); mark++) {
		if (!marks_set[mark])
			continue;
		_file_get_blockoff(file, marks[mark], &file->marks[mark]);
	}

	fclose(swp);
	return file;

fail_close:
	fclose(swp);
	errno = 0;
fail_done:
	{
		int errno_save = errno;
		file_basic_done(file);
		errno = errno_save;
	}
fail_total:
	return NULL;
}

struct ffb_hookdata {
	struct file *file;
	blockoff_t *pos;
	ssize_t blen;
	int error;
	reg_callback base_ecb;
	void *base_ecb_data;
};

static void
eval_reg_cb(void *hookdata, char reg, bint ofs, int mpos, unsigned char *scramble, int len)
{
	struct ffb_hookdata *data = hookdata;
	if (reg == '.') {
		if (file_read_begin(data->file, data->pos, data->blen))
			data->error = 1;
		else if (file_cpin(data->file, scramble, len, data->pos))
			data->error = 1;
		file_read_end(data->file);
	} else {
		data->base_ecb(data->base_ecb_data, reg, ofs, mpos, scramble, len);
	}
}

static void
reverse(unsigned char *p, size_t len)
{
	unsigned char *q = p + len;
	while (p < q) {
		unsigned char x = *p;
		*p++ = *--q;
		*q = x;
	}
}

static void
compute_badchar(ssize_t *badchar, const unsigned char *s, size_t len)
{
	size_t i = 1;
	while (i < len)
		badchar[*s++] = i++;
}

static void
compute_sfx(ssize_t *sfx, const unsigned char *s, size_t len)
{
	ssize_t f, g, i;

	sfx[len - 1] = len;
	g = len - 1;
	for (i = len - 2; i >= 0; --i) {
		if (i > g && sfx[i + len - 1 - f] < i - g)
			sfx[i] = sfx[i + len - 1 - f];
		else {
			if (i < g)
				g = i;
			f = i;
			while (g >= 0 && s[g] == s[g + len - 1 - f])
				--g;
			sfx[i] = f - g;
		}
	}
}

static void
compute_goodsfx(ssize_t *goodsfx, const unsigned char *s, size_t len)
{
	ssize_t i, j, *sfx = goodsfx + len;

	compute_sfx(sfx, s, len);

	for (i = 0; i < len; ++i)
		goodsfx[i] = len;
	j = 0;
	for (i = len - 1; i >= 0; --i)
		if (sfx[i] == i + 1)
			for (; j < len - 1 - i; ++j)
				if (goodsfx[j] == len)
					goodsfx[j] = len - 1 - i;
	for (i = 0; i <= len - 2; ++i)
		goodsfx[len - 1 - sfx[i]] = len - 1 - i;
}

/* Search for a constant byte string using the Boyer-Moore algorithm. */
static int
find_bytestr(struct file *file, blockoff_t *from, int dir,
	     unsigned char *needle, size_t len)
{
	void *dynalloc;
	ssize_t *badchar, *goodsfx;
	unsigned char *readbuf;
	ssize_t i;

	if (!(dynalloc = calloc(sizeof(ssize_t) * (256 + 2*len) + len, 1)))
		return FINDOFF_ERROR;

	badchar = dynalloc;
	goodsfx = badchar + 256;
	readbuf = dynalloc + sizeof(ssize_t) * (256 + 2*len);

	if (dir < 0) {
		reverse(needle, len);
		file_move_rel_fast(from, -(ssize_t)len);
	}

	compute_badchar(badchar, needle, len);
	compute_goodsfx(goodsfx, needle, len);

	for (;;) {
		unsigned char *p;
		ssize_t shift;

		if (ensure_uptodate(file, from)) {
			free(dynalloc);
			return FINDOFF_ERROR;
		}

		if (!block_is_virtual(from->block) &&
		    from->off + len <= from->block->t.size) {
			p = block_data(from->block) + from->off;
			from->off += len;
			from->pos += len;
		} else if (!copy_in(file, readbuf, len, from)) {
			p = readbuf;
		} else {
			free(dynalloc);
			return FINDOFF_ERROR;
		}

		i = len;
		if (dir < 0) {
			--p;
			while (p++, i--)
				if (needle[i] != *p)
					break;
		} else {
			p += i;
			while (p--, i--)
				if (needle[i] != *p)
					break;
		}
		if (i < 0) {
			file_move_rel_fast(from, -(ssize_t)len);
			free(dynalloc);
			return 0;
			/* For search&replace we might micro-optimize by
			 * returning the minimum shift for the next try
			 */
#if 0
			return *goodsfx;
#endif
		}

		shift = i + 1 - badchar[*p];
		if (shift < goodsfx[i])
			shift = goodsfx[i];

		if (dir < 0) {
			shift += len;
			from->pos -= shift;
			from->off -= shift;
		} else {
			shift -= len;
			from->pos += shift;
			from->off += shift;
		}
		if (0 > from->pos || from->pos > file->size - len)
			break;
		fixup_blockoff(from);
	}

	free(dynalloc);
	return FINDOFF_NO_MATCH;
}

static int
find_expr(struct file *file, blockoff_t *from, int dir,
	  struct expression *expr,
	  struct ffb_hookdata *data, unsigned char **pbuf)
{
	int len = expr_len(expr);

	assert(len > 0);

	if (len > file->size)
		return FINDOFF_NO_MATCH;
	if ((off_t)file->size - from->pos - len < 0)
		file_move_relative(from, (off_t)file->size - from->pos - len);

	for (;;) {
		blockoff_t match;
		size_t remain;
		unsigned char *p;
		int pos;

		data->blen = len;
		if (!*pbuf)
			*pbuf = expr_eval(expr, eval_reg_cb, NULL, &data);
		if (!*pbuf || data->error)
			return FINDOFF_ERROR;

		if (file_read_begin(file, from, data->blen))
			return FINDOFF_ERROR;

		file_dup_blockoff(from, &match);
		p = block_data(match.block) + match.off;
		remain = match.block->t.size;
		for (pos = 0; pos < len; pos++) {
			if (!remain) {
				if (file_next_block(data->file, &match))
					break;
				p = block_data(match.block) + match.off;
				remain = match.block->t.size;
			}
			if (file_read_deref(p++) != (*pbuf)[pos])
				break;
			remain--;
		}

		file_put_blockoff(&match);
		file_read_end(file);

		if (pos == len)
			return 0;

		from->pos += dir;
		from->off += dir;
		if (0 > from->pos || from->pos > file->size - len)
			break;
		fixup_blockoff(from);

		if (expr_is_const(expr))
			return find_bytestr(file, from, dir, *pbuf, len);

		free(*pbuf);
		*pbuf = NULL;
	}

	return FINDOFF_NO_MATCH;
}

int
file_find_expr(struct file *file, blockoff_t *pos, int dir,
	       struct expression *expr,
	       reg_callback expr_cb, void *expr_cb_data)
{
	struct ffb_hookdata data;
	unsigned char *buf = NULL;
	int res;

	assert(dir == 1 || dir == -1);

	data.file = file;
	data.pos = pos;
	data.error = 0;
	data.base_ecb = expr_cb;
	data.base_ecb_data = expr_cb_data;

	file_set_readahead(file, dir > 0 ? FILE_RA_FORWARD : FILE_RA_BACKWARD);
	res = find_expr(file, pos, dir, expr, &data, &buf);
	file_set_readahead(file, FILE_RA_NONE);

	if (buf)
		free(buf);

	return res;
}
