/* The read fixup code */
/* $Id$ */

/*
 * hed - Hexadecimal editor
 * Copyright (C) 2004  Petr Baudis <pasky@ucw.cz>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "config.h"

#include <signal.h>

#include "hed.h"
#include "file/fixup.h"

#ifdef CONFIG_FIXUP

void *fixup_last_addr;
unsigned char fixup_enabled;

static const unsigned char null_byte;

static void
sigbus_handler(int sig, struct siginfo *si, void *ctx)
{
	if (fixup_enabled && si->si_addr != fixup_last_addr) {
		fixup_last_addr = si->si_addr;
		arch_load_fixup((struct ucontext*)ctx);
	} else {
		/* Restart the instruction and fail */
		signal(SIGBUS, SIG_DFL);
	}
}

int
fixup_init(void)
{
	struct sigaction sa;

	sa.sa_flags = SA_SIGINFO;
	sa.sa_sigaction = sigbus_handler;
	sigemptyset(&sa.sa_mask);

	return sigaction(SIGBUS, &sa, NULL);
}

#endif	/* CONFIG_MMAP */
