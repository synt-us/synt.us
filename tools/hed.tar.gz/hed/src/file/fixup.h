/* The read fixup code */
/* $Id$ */

/*
 * hed - Hexadecimal editor
 * Copyright (C) 2004  Petr Baudis <pasky@ucw.cz>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef HED__FILE_FIXUP_H
#define HED__FILE_FIXUP_H

#ifdef CONFIG_MMAP

extern unsigned char fixup_enabled;
extern void *fixup_last_addr;

#define CONFIG_FIXUP

#if defined(__x86_64) || defined(__x86_64__)

static inline unsigned char
__fixup_read(const unsigned char *p)
{
	unsigned char ret;

	asm ("movb (%1),%0" :  "=q" (ret) : "D" (p));
	return ret;
}

#define arch_load_fixup(ctx) \
	(void)((ctx)->uc_mcontext.gregs[REG_RDI] = (unsigned long)&null_byte)

#elif defined(__i386) || defined(__i386__)

static inline unsigned char
__fixup_read(const unsigned char *p)
{
	unsigned char ret;

	asm ("movb (%1),%0" :  "=q" (ret) : "D" (p));
	return ret;
}

#define arch_load_fixup(ctx) \
	(void)((ctx)->uc_mcontext.gregs[REG_EDI] = (unsigned long)&null_byte)

#else

/* These architectures will get killed with SIGBUS */
# undef CONFIG_FIXUP

#endif

#endif /* CONFIG_MMAP */

#ifdef CONFIG_FIXUP

int fixup_init(void);
#define fixup_begin()	do {	\
	fixup_last_addr = NULL;	\
	fixup_enabled = 1;	\
} while(0)
#define fixup_end()	do { fixup_enabled = 0; } while(0)
static inline unsigned char
fixup_read(const unsigned char *p)
{
    return fixup_last_addr ? 0 : __fixup_read(p);
}

#else

#define fixup_enabled	0
#define fixup_last_addr	NULL

#define fixup_init()
#define fixup_begin()
#define fixup_end()
#define __fixup_read(p)	(*(p))
#define fixup_read(p)	(*(p))

#endif /* CONFIG_FIXUP */

#endif
