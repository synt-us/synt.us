/* $Id: lists.h,v 1.41 2004/07/14 00:24:24 jonas Exp $ */

#ifndef HED__FILE_TREE_H
#define HED__FILE_TREE_H

#include "config.h"

#include "util/lists.h"

/* Behold, a tree! */
struct tree {
	struct tree_head *root;
	/* Doubly linked list of nodes */
	struct list_head list;
};

struct tree_head {
	/* Used for the linked list */
	struct list_head link;
	/* Can be the null node for the root. */
	struct tree_head *up;
	/* Both can be the null node for leaves. */
	struct tree_head *left;
	struct tree_head *right;
	/* Size of the entry. (This is public.) */
	uoff_t size;
	/* Size of the entry plus its children. (Private.) */
	uoff_t cover_size;
};

/**
 * tree_entry - get the struct for this entry
 * @ptr:	the &struct tree_head pointer.
 * @type:	the type of the struct this is embedded in.
 * @member:	the name of the struct tree_head within the struct.
 */
#define tree_entry(ptr, type, member) ({			\
	const struct tree_head *__mptr = (ptr);			\
	(type *)( (char *)__mptr - offsetof(type,member) );})

#define tree_list_entry(ptr)	list_entry(ptr,struct tree_head,link)

#define null_node(t)	tree_list_entry(&(t)->list)
#define is_a_node(t,n)	((n) != null_node(t))

/* These prototypes may be in fact defined as macros below! */

static inline void
init_tree(struct tree *tree)
{
	tree->root = null_node(tree);
	INIT_LIST_HEAD(&tree->list);
}

#define init_node(node)	INIT_LIST_HEAD(&(node)->link)

/* Update node information */
void recalc_node_recursive(struct tree *tree, struct tree_head *item);

/* Delete from the tree, but do NOT recalculate parent nodes. Use this when
 * replacing one node with another (equally sized). However, you SHOULD
 * recalculate when merging two nodes together etc. - the cover sizes
 * might not be right if you merged a child in. */
void del_from_tree(struct tree *tree, struct tree_head *item);

/* Delete from the tree and recalculate parent nodes. */
void recalc_del_from_tree(struct tree *tree, struct tree_head *item);

/* Insert a new item after @pos. If @pos is the null node, insert
 * at the beginning. */
void insert_into_tree(struct tree *tree, struct tree_head *item,
		      struct tree_head *pos);

/* Append an item after the last item in tree. */
void append_to_tree(struct tree *tree, struct tree_head *item);

/* Finds the item at or right before the given offset (except when there is
 * no item at or before the offset; then it gives the nearest item after
 * the offset; you can distinguish the case by item->left being the
 * null node. */
struct tree_head *find_in_tree(struct tree *tree, uoff_t offset);

#define first_in_tree(tree)	tree_list_entry((tree)->list.next)
#define prev_in_tree(item)	tree_list_entry((item)->link.prev)
#define next_in_tree(item)	tree_list_entry((item)->link.next)
#define last_in_tree(tree)	tree_list_entry((tree)->list.prev)

uoff_t tree_block_offset(struct tree *tree, struct tree_head *block);

/* You shouldn't need to call these directly unless you want to
 * do special optimizations for certain items. */
void splay(struct tree *tree, struct tree_head *item);
void unsplay(struct tree *tree, struct tree_head *item);

#define foreach_in_tree(e, t, type, member) \
	for ((e) = tree_entry(first_in_tree(t),type,member); \
	     &(e)->member != null_node(t); \
	     (e) = tree_entry(next_in_tree(&(e)->member),type,member))

#define foreachsafe_in_tree(e, n, t, type, member) \
	for ((e) = tree_entry(first_in_tree(t),type,member), \
	     (n) = tree_entry(next_in_tree(&(e)->member),type,member); \
	     &(e)->member != null_node(t); \
	     (e) = (n), \
	     (n) = tree_entry(next_in_tree(&(e)->member),type,member))

#endif
