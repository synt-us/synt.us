/*
 * hed - Hexadecimal editor
 * Copyright (C) 2008  Petr Tesarik <petr@tesarici.cz>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "config.h"

#include <stdlib.h>
#include <string.h>
#include "file/cache.h"

#undef CACHE_DEBUG
#ifdef CACHE_DEBUG
# include <stdio.h>
# define CDEBUG(x...) fprintf(stderr, x)
#else
# define CDEBUG(x...)
#endif

size_t
file_cache_size(unsigned nelem, size_t block_size, bool embed)
{
	return sizeof(struct file_cache)
		+ nelem * (sizeof (struct file_data*)   /* used */
			   + sizeof(struct file_data*)  /* revmap */
			   + sizeof(struct file_data)   /* objects */
			   + (embed ? block_size : 0)); /* data */
}

void file_cache_init(struct file_cache *cache, unsigned nelem,
		     size_t block_size, bool embed)
{
	struct file_data **revmap = (void*)cache
		+ sizeof(struct file_cache)
		+ nelem * sizeof(struct file_data*);
	struct file_data *data = (void*)revmap
		+ nelem * sizeof(struct file_data*);
	void *pdata = (void*)data
		+ nelem * sizeof(struct file_data);
	struct list_head *plink;

	CDEBUG("Initialize a cache at %p with %d elements:\n", cache, nelem);

	cache->block_size = block_size;
	cache->embed = embed;
	cache->nelem = nelem;
	cache->revmap = revmap;
	cache->data = pdata;
	cache->used_end = cache->used;
	plink = &cache->free;
	while (nelem--) {
		CDEBUG("  file_data at %p\n", data);

		plink->next = &data->u2.free;
		data->size = block_size;
		if (embed) {
			data->data = pdata;
			pdata += block_size;
		}
		data->dirtybits = 0;
		data->u1.cflags = 0;
		data->u2.free.prev = plink;
		plink = &data->u2.free;
		*revmap++ = data++;
	}

	plink->next = &cache->free;
	cache->free.prev = plink;
}

static inline struct file_data *
search_used(struct file_cache *cache, uoff_t pos)
{
	struct file_data **p;

	for (p = cache->used; p < cache->used_end; ++p)
		if ((*p)->pos == pos)
			return *p;
	return NULL;
}

struct file_data *
file_cache_alloc(struct file_cache *cache, uoff_t pos)
{
	struct file_data *item;
	int newflags;

	CDEBUG("Allocating a new cache object... ");

	if ( (item = search_used(cache, pos)) ) {
		CDEBUG("already loaded at %p%s\n", item,
		       item->u1.cflags & FDC_INUSE ? "" : " (freed)");
		if (item->u1.cflags & FDC_INUSE) {
			file_cache_get(item);
			item->u2.used.flags |= FDF_REUSED;
			return item;
		}
		newflags = FDF_CACHED | FDF_REUSED;
	} else {
		if (list_empty(&cache->free)) {
			CDEBUG("failed (cache full)\n");
			return NULL;
		}
		item = list_entry(cache->free.next, struct file_data, u2.free);

		CDEBUG("ok, allocated at %p\n", item);

		if (! (item->u1.cflags & FDC_USED))
			*cache->used_end++ = item;
		newflags = FDF_CACHED;
	}

	/* Initialize a not-in-use entry */
	list_del(&item->u2.free);
	item->pos = pos;
	item->u2.used.refcount = 1;
	item->u2.used.flags = newflags;
	item->u1.cflags |= FDC_INUSE | FDC_USED;

	return item;
}

void
file_cache_invalidate(struct file_cache *cache)
{
	struct file_data **pused;

	CDEBUG("Invalidating all cache entries... ");

	for (pused = cache->used; pused < cache->used_end; ++pused)
		(*pused)->u1.cflags &= ~FDC_USED;
	cache->used_end = cache->used;
}

#if defined(CONFIG_READAHEAD) && !defined(CONFIG_MMAP)

/* Make data slot at @srcidx available for re-use by relocating
 * the data for its corresponding entry to data slot at @dstidx.
 * WARNING: This function does not re-initialize the dest entry.
 * That must be done by the caller.
 */
static void
move_entry(struct file_cache *cache, unsigned srcidx, unsigned dstidx)
{
	struct file_data **revmap = cache->revmap;
	struct file_data *src = revmap[srcidx];
	struct file_data *dst = revmap[dstidx];
	void *data;

	CDEBUG("Moving data slot %d to %d\n", srcidx, dstidx);

	revmap[dstidx] = src;
	data = src->data;
	src->data = dst->data;
	memcpy(dst->data, data, cache->block_size);
}

#ifdef CACHE_DEBUG

static void
dump_usemap(unsigned char *map, unsigned nelem)
{
	unsigned i;

	for (i = 0; i < nelem; ++i)
		putc(map[i] ? '#' : '.', stderr);
	putc('\n', stderr);
}

#else  /* CACHE_DEBUG */

#define dump_usemap(u,n)	do{} while(0)

#endif

static unsigned
reorder_elements(struct file_cache *cache, struct file_data **items, int n)
{
	const size_t block_size = cache->block_size;
	void *base = cache->data;
	unsigned char used[2*n];
	unsigned pool[2*n];
	int npool, npoolhi;
	int hi, usedoff;
	int i;

	memset(used, 0, sizeof used);
	hi = cache->nelem - n;
	npool = npoolhi = 0;
	for (i = 0; i < n; ++i) {
		unsigned idx = (items[i]->data - base) / block_size;
		if (idx < n)
			used[idx] = 1;
		else
			pool[npool++] = idx;
		if (idx > hi)
			used[n + idx - hi] = 1;
		else
			pool[n + npoolhi++] = idx;
	}

	CDEBUG("Reorder %d elements:\n", n);
	CDEBUG("lo: "); dump_usemap(used, n);
	CDEBUG("hi: "); dump_usemap(used + n, n);

	if (npoolhi < npool) {
		npool = n + npoolhi;
		usedoff = n;
	} else
		usedoff = hi = 0;

	for (i = 0; i < n; ++i)
		if (!used[i + usedoff])
			move_entry(cache, i + hi, pool[--npool]);
	assert(npool == usedoff);

	return hi;
}

void
file_cache_compact(struct file_cache *cache, struct file_data **items, int n)
{
	void *lower, *upper, *p;
	const size_t block_size = cache->block_size;
	unsigned firstslot;
	int i;

	lower = upper = items[0]->data;
	for (i = 1; i < n; ++i) {
		assert(items[i]->u2.used.flags & FDF_CACHED);
		if (items[i]->data < lower)
			lower = items[i]->data;
		else if (items[i]->data > upper)
			upper = items[i]->data;
	}

	if (upper - lower > n * block_size) {
		firstslot = reorder_elements(cache, items, n);
		p = cache->data + firstslot * block_size;
	} else {
		firstslot = (lower - cache->data) / block_size;
		p = lower;
	}

	for (i = 0; i < n; ++i) {
		items[i]->data = p;
		cache->revmap[i + firstslot] = items[i];
		p += block_size;
	}
}

#endif

int
file_data_init(struct file_data *item, uoff_t pos, size_t size)
{
	item->size = size;
	item->data = malloc(size);
	if (!item->data)
		return -1;
	item->dirtybits = 0;
	item->pos = pos;
	item->u2.used.refcount = 1;
	item->u2.used.flags = 0;
	return 0;
}

static struct file_data *
alloc_new(uoff_t pos, size_t size, size_t dirtybits, bool withdata)
{
	struct file_data *item =
		calloc(1, sizeof(struct file_data) + dirtybits / 8);

	CDEBUG("Allocated an out-of-cache object: %p\n", item);

	if (!item)
		return NULL;

	item->size = size;
	if (withdata && !(item->data = malloc(size))) {
		free(item);
		return NULL;
	}
	item->dirtybits = dirtybits;
	item->u1.bytedirty = (void*)item + sizeof(struct file_data);
	item->pos = pos;
	item->u2.used.refcount = 1;
	item->u2.used.flags = FDF_OWNED;

	return item;
}

struct file_data *
file_data_new(uoff_t pos, size_t size)
{
	return alloc_new(pos, size, 0, true);
}

int
file_data_realloc(struct file_data *data, size_t newsize)
{
	void *newdata;

	CDEBUG("Resizing object at %p from %d to %d\n",
	       data, data->size, newsize);

	if (! (newdata = realloc(data->data, newsize)) )
		return -1;

	data->data = newdata;
	data->size = newsize;
	return 0;
}

/* This function can handle both cached and out-of-cache objects. */
void
_file_data_free(struct file_cache *cache, struct file_data *data)
{
	CDEBUG("Releasing object at %p: ", data);
	if (! (data->u2.used.flags & FDF_CACHED)) {
		CDEBUG("deallocated\n");
		if (data->data)
			free(data->data);
		if (data->u2.used.flags & FDF_OWNED)
			free(data);
	} else {
		CDEBUG("returned to cache\n");

		data->u1.cflags &= ~FDC_INUSE;
		list_add_tail(&data->u2.free, &cache->free);
	}
}

struct file_data *
file_cache_detach(struct file_cache *cache, struct file_data *old)
{
	struct file_data *new;

	CDEBUG("Making an out-of-cache copy of the object at %p\n", old);

	new = alloc_new(old->pos, cache->block_size, cache->block_size,
			cache->embed);
	if (!new)
		return NULL;

	if (cache->embed)
		memcpy(new->data, old->data, cache->block_size);
	else
		new->data = old->data;

	file_cache_put(cache, old);

	return new;
}
