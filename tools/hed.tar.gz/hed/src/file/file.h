/* The file handling */
/* $Id$ */

/*
 * hed - Hexadecimal editor
 * Copyright (C) 2004  Petr Baudis <pasky@ucw.cz>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef HED__FILE_FILE_H
#define HED__FILE_FILE_H

#include "config.h"

#include <string.h>
#include <sys/stat.h>

#include "eval/eval.h"
#include "file/fixup.h"

#include "file/cache.h"
#include "file/tree.h"
#include "util/lists.h"

/* File object */

#ifdef CONFIG_MMAP
# define FILE_BLOCK_SIZE sys_page_size
extern long sys_page_size;	/* Page size (in bytes) */
#else
# define FILE_BLOCK_SIZE 4096
#endif

#define FILE_BLOCK_OFF(x)	((x) & (FILE_BLOCK_SIZE-1))
#define FILE_BLOCK_ROUND(x)	((x) & ~(FILE_BLOCK_SIZE-1))

#define CACHE_LENGTH 64

/* Blocks for readahead */
#define FILE_READAHEAD	(CACHE_LENGTH/2)

/* Dynamic allocation increment (granularity) */
#define FILE_ALLOC_INC	1024

/* The block cache is organized as follows:
 *
 * At the start, there are two virtual blocks:
 * --
 *
 * The first block covers the edited file (and has a physical size
 * equal to the size of the file), the second block covers all
 * possible file offsets beyond EOF (and has zero physical size).
 *
 * Then we can do a read and turn the virtual block to two, or shift its
 * start/end:
 * -x-
 *
 * After a while...
 * x-xxx-xx-x-xxxxxxx-x
 *
 * As you can see, virtual blocks can have any size and stretch variably
 * and fill the gaps between real blocks which have a size limit.
 *
 * Now, we can dirty some blocks:
 * x-xxX-xx-x-xxxxxxx-x
 *
 * Even if we insert anything to the block, other blocks aren't touched,
 * except when the block size hits the limit - then, the block will spawn
 * another one:
 * x-xxXX-xx-x-xxxxxxx-x
 *
 * Again, we don't touch other blocks during deletion. Only when the block
 * size hits zero, we kill it:
 * x-xxXX-xx-x-xxxxxx-x
 *
 * Note that we still keep around blocks which have any counterpart in the
 * file, even if they are already dead in our current file image. This is
 * necessary when reading more file blocks to the cache and when commiting
 * the changes, in order to maintain offset consistency.
 *
 * When can size != phys_size?
 * * byte(s) have been INSERTED into this block: size > phys_size
 *	Special case is an entire new block:
 *		in case of virtual blocks, phys_size MUST == 0 (gap)
 * * byte(s) have been ERASED from this block: size < phys_size
 *	Virtual blocks are not permitted
 */

struct file_block {
	struct tree_head t;
	struct list_head lru;

	/* Flags - see BLOCK_xxx below. */
	long flags;

	/* List of blockoff_t offsets which reference this
	 * structure.  This is more flexible than refcounting,
	 * because you may actually do something to the file_block,
	 * as long as you update all the blockoff_t structs.
	 */
	struct list_head refs;

	/* These are only valid for non-virtual blocks */
	struct file_data *dataobj;
	size_t dataoff;

	/* Physical position of this block. */
	uoff_t phys_pos;
};

/* A blockoff_t consists of file position, its corresponding
 * block pointer and the offset within that block.
 */
typedef struct {
	off_t pos;
	struct file_block *block;
	uoff_t off;
	struct list_head list;
} blockoff_t;

#define NULL_BLOCKOFF	{ 0, NULL, 0 }

#define BLOCK_DIRTY	0x01	/* data has been modified */
#define BLOCK_INSERTED	0x02	/* insert/delete block */
#define BLOCK_EXCACHE	0x04	/* block is NOT in the cache[] array
				 * and can be freed after it is undirtied */
#define BLOCK_VIRTUAL	0x08	/* "Virtual" block - must never be dirty
				 * nor excache; data is not valid - only
				 * size is meaningful. */
#define BLOCK_EOF	0x10	/* Purely virtual block beyond EOF. */

#define block_is_dirty(b)	((b)->flags & BLOCK_DIRTY)
#define block_set_dirty(b)	((b)->flags |= BLOCK_DIRTY)
#define block_clear_dirty(b)	((b)->flags &= ~BLOCK_DIRTY)

#define block_is_inserted(b)	((b)->flags & BLOCK_INSERTED)
#define block_set_inserted(b)	((b)->flags |= BLOCK_INSERTED)
#define block_clear_inserted(b)	((b)->flags &= ~BLOCK_INSERTED)

#define block_is_excache(b)	((b)->flags & BLOCK_EXCACHE)
#define block_set_excache(b)	((b)->flags |= BLOCK_EXCACHE)
#define block_clear_excache(b)	((b)->flags &= ~BLOCK_EXCACHE)

#define block_is_virtual(b)	((b)->flags & BLOCK_VIRTUAL)
#define block_set_virtual(b)	((b)->flags |= BLOCK_VIRTUAL)
#define block_clear_virtual(b)	((b)->flags &= ~BLOCK_VIRTUAL)

#define block_is_eof(b)		((b)->flags & BLOCK_EOF)
#define block_set_eof(b)	((b)->flags |= BLOCK_EOF)
#define block_clear_eof(b)	((b)->flags &= ~BLOCK_EOF)

#define block_is_inner_virtual(b)	\
	(((b)->flags & (BLOCK_VIRTUAL | BLOCK_EOF)) == BLOCK_VIRTUAL)

/* flags related to block allocation */
#define BLOCK_ALLOCMASK	(BLOCK_EXCACHE)

/* flags related to block state */
#define BLOCK_STATEMASK	(BLOCK_DIRTY | BLOCK_INSERTED | BLOCK_VIRTUAL)

static inline int
block_bytedirty(const blockoff_t *blockoff)
{
	struct file_block *block = blockoff->block;
	return block->dataobj &&
		file_data_is_bytedirty(block->dataobj,
				       block->dataoff + blockoff->off);
}

static inline void
block_set_bytedirty(const blockoff_t *blockoff)
{
	struct file_block *block = blockoff->block;
	if (block->dataobj)
		file_data_set_bytedirty(block->dataobj,
					block->dataoff + blockoff->off);
}

static inline void
block_clear_bytedirty(const blockoff_t *blockoff)
{
	struct file_block *block = blockoff->block;
	if (block->dataobj)
		file_data_clear_bytedirty(block->dataobj,
					  block->dataoff + blockoff->off);
}

static inline unsigned char *
block_data(struct file_block *block)
{
	return block->dataobj
		? block->dataobj->data + block->dataoff
		: NULL;
}

struct file {
	const char *name;
	struct stat s;
	uoff_t size, phys_size;
	int fd;			/* file descriptor for read-only access */
	bool modified;

	/* This list contains clean file-backed blocks.
	 * It is sorted from least recently used to most recently used. */
	struct list_head lru;

	/* This cache holds the data for clean file-backed blocks. */
	struct file_cache *cache;

	/* The file blocks are sorted by the offset in this list. */
	struct tree blocks;

#ifdef CONFIG_READAHEAD
	enum {
		FILE_RA_NONE,	  /* No readahead */
		FILE_RA_FORWARD,  /* Read-ahead forwards */
		FILE_RA_BACKWARD  /* Read-ahead backwards */
	} readahead;
#endif

	blockoff_t marks['z' - 'a' + 1 + 'Z' - 'A' + 1];
};

#ifdef CONFIG_READAHEAD
static inline void
file_set_readahead(struct file *file, int val)
{
	file->readahead = val;
}
#else
# define file_set_readahead(file,t) do {} while(0)
#endif

#define block_offset(tree,b)		tree_block_offset((tree), &(b)->t)

static inline uoff_t
file_block_size(struct file_block *block)
{
	return block->t.size;
}

#define null_block(tree) (tree_entry(null_node(tree),struct file_block,t))

#define first_block(tree) (tree_entry(first_in_tree(tree),struct file_block,t))
#define prev_block(b) (tree_entry(prev_in_tree(&(b)->t),struct file_block,t))
#define next_block(b) (tree_entry(next_in_tree(&(b)->t),struct file_block,t))
#define last_block(tree) (tree_entry(last_in_tree(tree),struct file_block,t))

/* false if this is not a block - out of list bounds */
#define is_a_block(tree,b) (&(b)->t != null_node(tree))
/* Whether the block is a blocks list member. */
#define is_chained_block(f,b) ((b)->t.up || (f)->blocks.root == &(b)->t)

#define recalc_node_recursive(tree,b)	recalc_node_recursive((tree),&(b)->t)

#define chain_block(tree,b) append_to_tree((tree), &(b)->t)
#define recalc_chain_block(tree,b) do { \
	chain_block((tree), (b)); \
	recalc_node_recursive((tree), (b)); \
} while (0)

#define chain_block_after(tree,p,b) insert_into_tree((tree), &(b)->t, &(p)->t)
#define recalc_chain_block_after(tree,p,b) do { \
	chain_block_after((tree), (p), (b)); \
	recalc_node_recursive((tree), (b)); \
} while (0)
#define unchain_block(tree,b) del_from_tree((tree), &(b)->t)
#define recalc_unchain_block(tree,b) recalc_del_from_tree((tree), &(b)->t)
#define init_block_list(tree) init_tree(tree)
#define init_block_link(b) init_node(&(b)->t)

#define foreach_block(b,tree) foreach_in_tree ((b),(tree),struct file_block,t)
#define foreachsafe_block(b,n,tree) foreachsafe_in_tree ((b),(n),(tree),struct file_block,t)

#define find_block(tree,o)	tree_entry(find_in_tree((tree),(o)),struct file_block,t)

/*******************************************************************
 * file object API
 */

/* Opens a file. */
struct file *file_init(const char *name);

/* Closes the file. */
void file_done(struct file *file);

/* Get the current file size */
static inline
uoff_t file_size(struct file *file)
{
	return file->size;
}

/* Update the file size from the file system */
int file_update_size(struct file *file);

/* Commits dirty blocks to the file. */
int file_commit(struct file *file);

/* Saves dump of internal structures to disk. */
void file_swp(struct file *file);

/* Loads dump of internal structures associated with given file from disk. */
struct file *file_unswp(const char *name);

/* Remoes dump of internal structures associated with given file from disk. */
void file_rmswp(const char *name);

/* Fetches the required part of the file. The real size is saved to *size.
 * On error, *size == 0, and the call returns NULL.
 * The error code is available in @errno.
 *
 * Please note that even for incomplete reads, the memory pointed at
 * by the return value will be allocated to the full size as specified
 * by *size. So should the buffer be held for a longer time, you might
 * want to reallocate the buffer to the exact length. */
void *file_fetch_block(struct file *file, uoff_t offset, size_t *size);

/* Converts a logical @offset to a block plus offset (@blockoff). Returns
 * non-zero on error, and the error code is available in @errno.
 */
void file_get_blockoff(struct file *file, uoff_t offset, blockoff_t *blockoff);

static inline void file_put_blockoff(blockoff_t *blockoff)
{
	list_del(&blockoff->list);
}

/* Duplicate into an empty blockoff_t */
void file_dup_blockoff(blockoff_t *src, blockoff_t *dst);

/* Duplicate into an initialized blockoff_t */
void file_dup2_blockoff(blockoff_t *src, blockoff_t *dst);

#define is_a_blockoff(blockoff)	(!!(blockoff)->block)

/* Relative move from a given block offset.
 * If the resulting position is out of bounds (either < 0 or > OFF_MAX),
 * the offset is adjusted to only move to 0 or OFF_MAX.
 * Returns the actual offset which was used.
 */
off_t file_move_relative(blockoff_t *blockoff, off_t num);

/* Given you know that offset is just one byte beyond the last span,
 * get the block which contains byte at @blockoff.
 * If the block is not available, it is loaded from disk, so do not
 * use this function if you only want to iterate through virtual
 * blocks.
 * Returns non-zero on error, and the error code is available in @errno.
 */
int file_next_block(struct file *file, blockoff_t *blockoff);

bool file_pos_after_erase(const struct file *file, blockoff_t *blockoff);

static inline bool
file_pos_valid(const struct file *file, const blockoff_t *blockoff)
{
	return !block_is_virtual(blockoff->block);
}

/* Ensure reads are valid from a block offset.
 * Returns:
 *  <0  on error
 *   0  on success (no change to the object)
 *  >0  on success (object was modified => invalidate blockoff pointers)
 */
int file_read_begin(struct file *file,
		    const blockoff_t *blockoff, size_t length);

static inline void
file_read_end(struct file *file)
{
#ifdef CONFIG_MMAP
	fixup_end();
#endif
}

static inline unsigned char
file_read_deref(const unsigned char *p)
{
#ifdef CONFIG_MMAP
	return fixup_read(p);
#else
	return *p;
#endif
}

/* Copy in @count bytes from file @file at @pos to @buf.
 * Returns number of bytes which were not copied, i.e. zero on success.
 */
size_t file_cpin(struct file *file, void *buf, size_t count, blockoff_t *pos);

/* Find a given sequence of bytes in the file, starting at the @pos file
 * offset and possibly wrapping around. @dir is +1 or -1. */
int file_find_expr(struct file *file, blockoff_t *pos, int dir, struct expression *expr, reg_callback expr_cb, void *expr_cb_data);
#define FINDOFF_NO_MATCH -1
#define FINDOFF_ERROR	 -2

/* Sets a single byte in the file. */
int file_set_byte(struct file *file, blockoff_t *blockoff, unsigned char byte);
/* Sets multiple bytes in the file. */
size_t file_set_block(struct file *file, blockoff_t *blockoff, unsigned char *buf, size_t len);
uoff_t file_set_bytes(struct file *file, blockoff_t *blockoff, unsigned char byte, uoff_t rep);

/* To insert bytes:
 *  1. call file_insert_begin() with the cursor position and store the
 *     insert physical position.
 *  2. call file_insert_byte() and/or file_insert_block() on the insert pos,
 *     possibly repeatedly
 *  3. call file_insert_end() on the insert pos and forget all about it;
 *     be careful with aliases, because the insert might get merged/freed
 */
int file_insert_begin(struct file *file,
		      blockoff_t *blockoff, blockoff_t *blockoff_ins);
void file_insert_end(struct file *file, blockoff_t *blockoff_ins);

/* Inserts a single byte to the file. */
int file_insert_byte(struct file *file, blockoff_t *blockoff, unsigned char byte);
/* Insert a block of bytes to the file. */
size_t file_insert_block(struct file *file, blockoff_t *blockoff, unsigned char *buf, size_t len);

/* Erases a single byte from the file. */
# define file_erase_byte(file,blockoff)	(file_erase_block((file),(blockoff),1))

/* Erases a block of bytes from the file. */
size_t file_erase_block(struct file *file, blockoff_t *blockoff, uoff_t len);

/*******************************************************************
 * HELPER FUNCTIONS
 */

static inline char
ch2mark(char ch)
{
	return ('a' <= ch && ch <= 'z') ? ch - 'a' :
	       ('A' <= ch && ch <= 'Z') ? 26 + ch - 'A' :
	       -1;
}

#endif
