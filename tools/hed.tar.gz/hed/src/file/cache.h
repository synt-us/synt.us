/* File cache handling */
/* $Id$ */

/*
 * hed - Hexadecimal editor
 * Copyright (C) 2008  Petr Tesarik <petr@tesarici.cz>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef HED__FILE_CACHE_H
#define HED__FILE_CACHE_H

#include "config.h"

#include "hed.h"
#include "util/lists.h"

/* This is the block data descriptor
 * The usage of some fields is not self-evident:
 *
 * @size	ALWAYS denotes the number of bytes which can fit
 *		into @data
 *
 * @data	may be embedded inside the file_data object,
 *		detached in a dynamically allocated array,
 *		or unmaintained (for cached blocks with CONFIG_MMAP)
 *
 * @bytedirty	points to an array of @dirtybits bits
 *		If @dirtybits is 0, the pointer must not be dereferenced.
 *		For objects which were allocated by the caller, this
 *		field is NULL. This can be (ab)used when reference count
 *		goes to zero to determine whether the object should be
 *		freed.
 *
 * @cflags	various flags for cached objects; this field is valid only
 *		for cached blocks, because they don't use @bytedirty
 *
 * Some additional notes:
 * - @data is always allocated for out-of-cache objects
 * - all bytes beyond @dirtybits are dirty; rationale:
 *   1.	for inserted blocks, @dirtybits can be set to 0 and the
 *	@bytedirty array need not be allocated at all
 *   2.	for physical blocks, @dirtybits is set to FILE_BLOCK_SIZE
 *	and @bytedirty needs not be re-allocated, because you never
 *	read more than FILE_BLOCK_SIZE bytes from disk in a single
 *	block, so any bytes beyond that must have been set in the editor
 * - sizeof(file_data) is 32 byte (or one cache-line) on x86;
 *   keep it like that if possible
 */
struct file_data {
	size_t size;		/* size of data */
	void *data;
	size_t dirtybits;	/* size of bytedirty in _bits_ */
	union {
		unsigned char *bytedirty;
		int cflags;
	} u1;

	uoff_t pos;		/* physical position */

	union {
		struct list_head free;	/* free list */
		struct {
			int refcount;	/* reference count */
			int flags;	/* flags (see FDF_* below) */
		} used;
	} u2;
};

#define FDC_INUSE	1	/* Is the object currently in-use? */
#define FDC_USED	2	/* Is this object in the used array? */

#define FDF_CACHED	1	/* Allocated from cache */
#define FDF_REUSED	2	/* Data was re-used */
#define FDF_OWNED	4	/* If allocated by the cache */

struct file_cache {
	size_t block_size;
	struct list_head free;
	bool embed;		/* embedded cache data? */
	unsigned nelem;
	struct file_data **revmap;
	void *data;
	struct file_data **used_end;
	struct file_data *used[];	/* ptrs to used cached objects */
};

/* Return the size (in bytes) of a cache with @nelem entries.
 * See file_cache_init for the description of @embed.
 */
size_t file_cache_size(unsigned nelem, size_t block_size, bool embed);

/* Initialize a cache object with @nelem entries.
 * If @embed is false, only the cache object descriptors are allocated.
 * If @embed is true, the memory for the cache data is allocated along
 * with the descriptors.
 */
void file_cache_init(struct file_cache *cache, unsigned nelem,
		     size_t block_size, bool embed);

/* Allocate an object from the cache.
 * The object is automatically referenced, so the caller must
 * call file_cache_put() on it when it is no longer needed.
 * Returns NULL if all slots are full.
 */
struct file_data *file_cache_alloc(struct file_cache *cache, uoff_t pos);

/* Compact an array of data items so that their data lies
 * in a contiguous memory chunk. */
void file_cache_compact(struct file_cache *cache,
			struct file_data **items, int n);

/* Initialize a pre-allocated object outside of the cache.
 * The object can hold @size bytes of data and its reference count
 * will be exactly one.
 * Returns zero on success, -1 on allocation failure.
 */
int file_data_init(struct file_data *item, uoff_t pos, size_t size);

/* Allocate a new object outside of the cache.
 * The object can hold @size bytes of data and its reference count
 * will be exactly one.
 * Returns NULL on allocation failure. */
struct file_data *file_data_new(uoff_t pos, size_t size);

/* Reallocate an object to a new data size.
 * NB: This can be done only to out-of-cache blocks.
 * Returns zero on success, -1 on allocation failure.
 * If the reallocation fails, the object is unchanged (i.e. still valid).
 */
int file_data_realloc(struct file_data *data, size_t newsize);

/* Free a data object.
 * This method is called internally by file_cache_put() when the
 * reference count drops to zero. It should never be called directly.
 */
void _file_data_free(struct file_cache *cache, struct file_data *data);

/* Detach a data object from the cache. */
struct file_data *file_cache_detach(struct file_cache *cache,
				    struct file_data *data);

/* Get a reference to a cache object. */
static inline void
file_cache_get(struct file_data *data)
{
	++data->u2.used.refcount;
}

/* Release a reference to a cache object. */
static inline void
file_cache_put(struct file_cache *cache, struct file_data *data)
{
	if (!--data->u2.used.refcount)
		_file_data_free(cache, data);
}

/* Empty the cache. */
void file_cache_invalidate(struct file_cache *cache);

static inline int
file_data_is_bytedirty(const struct file_data *data, size_t off)
{
	return !(data->u2.used.flags & FDF_CACHED) &&
		(off >= data->dirtybits ||
		 data->u1.bytedirty[off>>3] & 1 << (off & 0x07));
}

static inline void
file_data_set_bytedirty(const struct file_data *data, size_t off)
{
	if (off < data->dirtybits)
		data->u1.bytedirty[off>>3] |= 1 << (off & 0x7);
}

static inline void
file_data_clear_bytedirty(const struct file_data *data, size_t off)
{
	if (off < data->dirtybits)
		data->u1.bytedirty[off>>3] &= ~(1 << (off & 0x7));
}

static inline int
file_data_is_reused(const struct file_data *data)
{
	return data->u2.used.flags & FDF_REUSED;
}

#endif
